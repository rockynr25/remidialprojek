-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 05 Jan 2020 pada 12.46
-- Versi Server: 5.6.25
-- PHP Version: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ajax`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `products`
--

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `price` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
--
-- Database: `aplikasi_penjualan`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL,
  `uname` varchar(30) NOT NULL,
  `pass` varchar(70) NOT NULL,
  `foto` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id`, `uname`, `pass`, `foto`) VALUES
(8, 'admin', '21232f297a57a5a743894a0e4a801fc3', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `barang`
--

CREATE TABLE IF NOT EXISTS `barang` (
  `id` int(11) NOT NULL,
  `nama` text NOT NULL,
  `jenis` text NOT NULL,
  `suplier` text NOT NULL,
  `modal` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `sisa` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `barang`
--

INSERT INTO `barang` (`id`, `nama`, `jenis`, `suplier`, `modal`, `harga`, `jumlah`, `sisa`) VALUES
(34, 'sampo', 'kesehatan', 'iksan', 200000, 300000, 35, 4),
(38, 'sampurna', 'rokok', 'pt sampurna', 22000, 23000, 10, 12),
(39, 'sabun', 'giv', 'ompong', 3000, 6000, 4, 4),
(42, 'sepatu', 'sport', 'Adidas', 75000, 80000, 5, 10),
(43, 'minuman dingin', 'minuman', 'iksan', 200000, 4000, 50, 50),
(44, 'minuman panas ', 'minuman', 'roki', 10000, 15000, 5, 5),
(45, 'minuman ', 'minuman', 'pajri', 10000, 15000, 5, 5);

-- --------------------------------------------------------

--
-- Struktur dari tabel `barang_laku`
--

CREATE TABLE IF NOT EXISTS `barang_laku` (
  `id` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `nama` text NOT NULL,
  `jumlah` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `total_harga` int(20) NOT NULL,
  `laba` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `barang_laku`
--

INSERT INTO `barang_laku` (`id`, `tanggal`, `nama`, `jumlah`, `harga`, `total_harga`, `laba`) VALUES
(73, '0000-00-00', 'gula', 2, 5500, 11000, 1000),
(74, '0000-00-00', 'kopii', 2, 3000, 6000, 2000),
(76, '2019-12-01', 'sampurna', 2, 24000, 48000, 4000),
(78, '2019-12-15', 'kopii', 1, 2500, 2500, 500),
(79, '0000-00-00', 'sepatu', 5, 80000, 400000, 25000),
(80, '2019-12-03', 'sampo', 5, 300000, 1500000, 500000);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `barang_laku`
--
ALTER TABLE `barang_laku`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `barang`
--
ALTER TABLE `barang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=46;
--
-- AUTO_INCREMENT for table `barang_laku`
--
ALTER TABLE `barang_laku`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=81;--
-- Database: `backup-20170130`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `absensi`
--

CREATE TABLE IF NOT EXISTS `absensi` (
  `id` int(11) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `datang` time DEFAULT NULL,
  `pulang` time DEFAULT NULL,
  `keterangan` text,
  `prakerin_siswa_id` int(11) NOT NULL,
  `status_kehadiran_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktur dari tabel `aspek_penilaian`
--

CREATE TABLE IF NOT EXISTS `aspek_penilaian` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) DEFAULT NULL,
  `nama_sekolah_id` int(11) NOT NULL,
  `kelompok_penilaian_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktur dari tabel `gol_darah`
--

CREATE TABLE IF NOT EXISTS `gol_darah` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `gol_darah`
--

INSERT INTO `gol_darah` (`id`, `nama`) VALUES
(4, 'A'),
(5, 'B'),
(6, 'AB'),
(7, 'O');

-- --------------------------------------------------------

--
-- Struktur dari tabel `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` mediumint(8) unsigned NOT NULL,
  `name` varchar(20) NOT NULL,
  `description` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `groups`
--

INSERT INTO `groups` (`id`, `name`, `description`) VALUES
(1, 'admin', 'Administrator'),
(2, 'members', 'General User'),
(3, 'Pembimbing Sekolah', 'Pembimbing');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenis_kelamin`
--

CREATE TABLE IF NOT EXISTS `jenis_kelamin` (
  `id` int(1) NOT NULL,
  `nama` varchar(50) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `jenis_kelamin`
--

INSERT INTO `jenis_kelamin` (`id`, `nama`) VALUES
(1, 'Laki-laki'),
(2, 'Perempuan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jenis_user`
--

CREATE TABLE IF NOT EXISTS `jenis_user` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `jenis_user`
--

INSERT INTO `jenis_user` (`id`, `nama`) VALUES
(1, 'administrator'),
(2, 'siswa'),
(3, 'pembimbing sekolah'),
(7, 'pembimbing unit');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kegiatan`
--

CREATE TABLE IF NOT EXISTS `kegiatan` (
  `id` int(11) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `mulai` time DEFAULT NULL,
  `selesai` time DEFAULT NULL,
  `uraian_kegiatan` text,
  `sarana` text,
  `prakerin_siswa_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktur dari tabel `kelas`
--

CREATE TABLE IF NOT EXISTS `kelas` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `kelas`
--

INSERT INTO `kelas` (`id`, `nama`) VALUES
(18, 'RPL2'),
(19, 'ANM2');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kelompok_penilaian`
--

CREATE TABLE IF NOT EXISTS `kelompok_penilaian` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `kelompok_penilaian`
--

INSERT INTO `kelompok_penilaian` (`id`, `nama`) VALUES
(4, 'Kepribadian'),
(5, 'Kedisiplinan'),
(6, 'produktivitas');

-- --------------------------------------------------------

--
-- Struktur dari tabel `login_attempts`
--

CREATE TABLE IF NOT EXISTS `login_attempts` (
  `id` int(11) unsigned NOT NULL,
  `ip_address` varchar(15) NOT NULL,
  `login` varchar(100) NOT NULL,
  `time` int(11) unsigned DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktur dari tabel `nama_sekolah`
--

CREATE TABLE IF NOT EXISTS `nama_sekolah` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) DEFAULT NULL,
  `alamat` varchar(45) DEFAULT NULL,
  `hp` varchar(45) DEFAULT NULL,
  `logo` varchar(45) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `nama_sekolah`
--

INSERT INTO `nama_sekolah` (`id`, `nama`, `alamat`, `hp`, `logo`) VALUES
(22, 'SMK NEGERI 1 CIOMAS', 'nio', '66', NULL),
(23, 'SMK NEGERI 1 CIBINONG', 'cibinong permai', '98989', NULL),
(24, 'SMK PGRI', 'BOGOR', '434234', NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembimbing_sekolah`
--

CREATE TABLE IF NOT EXISTS `pembimbing_sekolah` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) DEFAULT NULL,
  `no_hp` varchar(45) DEFAULT NULL,
  `nama_sekolah_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `pembimbing_sekolah`
--

INSERT INTO `pembimbing_sekolah` (`id`, `nama`, `no_hp`, `nama_sekolah_id`) VALUES
(3, 'Sample', '088577', 22);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembimbing_unit`
--

CREATE TABLE IF NOT EXISTS `pembimbing_unit` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) DEFAULT NULL,
  `no_hp` varchar(45) DEFAULT NULL,
  `nip` varchar(45) DEFAULT NULL,
  `unit_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `pembimbing_unit`
--

INSERT INTO `pembimbing_unit` (`id`, `nama`, `no_hp`, `nip`, `unit_id`) VALUES
(4, 'Asep Mulyana', '084', '13213', 5);

-- --------------------------------------------------------

--
-- Struktur dari tabel `penilaian`
--

CREATE TABLE IF NOT EXISTS `penilaian` (
  `id` int(11) NOT NULL,
  `nilai_angka` float DEFAULT NULL,
  `nilai_huruf` varchar(45) DEFAULT NULL,
  `keterangan` text,
  `prakerin_siswa_id` int(11) NOT NULL,
  `aspek_penilaian_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktur dari tabel `permasalahan`
--

CREATE TABLE IF NOT EXISTS `permasalahan` (
  `id` int(11) NOT NULL,
  `tanggal` date DEFAULT NULL,
  `masalah` text,
  `solusi` text,
  `oleh` varchar(45) DEFAULT NULL,
  `prakerin_siswa_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktur dari tabel `prakerin_siswa`
--

CREATE TABLE IF NOT EXISTS `prakerin_siswa` (
  `id` int(11) NOT NULL,
  `unit_id` int(11) NOT NULL,
  `kelas_id` int(11) NOT NULL,
  `tanggal_mulai` date DEFAULT NULL,
  `tanggal_selesai` date DEFAULT NULL,
  `jabatan_pembimbing` varchar(255) DEFAULT NULL,
  `siswa_id` int(11) NOT NULL,
  `pembimbing_unit_id` int(11) NOT NULL,
  `pembimbing_sekolah_id` int(11) NOT NULL,
  `jabatan_pembimbing_sekolah` varchar(255) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `prakerin_siswa`
--

INSERT INTO `prakerin_siswa` (`id`, `unit_id`, `kelas_id`, `tanggal_mulai`, `tanggal_selesai`, `jabatan_pembimbing`, `siswa_id`, `pembimbing_unit_id`, `pembimbing_sekolah_id`, `jabatan_pembimbing_sekolah`) VALUES
(33, 5, 19, '2017-01-30', '2017-01-31', 'sekertariat', 21, 4, 3, 'kepala sekolah'),
(34, 5, 18, '2017-01-26', '2017-02-27', 'Kasubdit', 27, 4, 3, 'kepala sekolah');

-- --------------------------------------------------------

--
-- Struktur dari tabel `program_keahlian`
--

CREATE TABLE IF NOT EXISTS `program_keahlian` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `program_keahlian`
--

INSERT INTO `program_keahlian` (`id`, `nama`) VALUES
(5, 'RPL'),
(6, 'ANIMASI'),
(7, 'TKR'),
(8, 'LAS'),
(10, 'MULTIMEDIA');

-- --------------------------------------------------------

--
-- Struktur dari tabel `rencana_kegiatan`
--

CREATE TABLE IF NOT EXISTS `rencana_kegiatan` (
  `id` int(11) NOT NULL,
  `uraian_kegiatan` varchar(45) DEFAULT NULL,
  `tanggal_mulai` date DEFAULT NULL,
  `tanggal_selesai` date DEFAULT NULL,
  `keterangan` varchar(45) DEFAULT NULL,
  `prakerin_siswa_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktur dari tabel `siswa`
--

CREATE TABLE IF NOT EXISTS `siswa` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) DEFAULT NULL,
  `foto` varchar(45) DEFAULT NULL,
  `nomor_induk` varchar(45) DEFAULT NULL,
  `tempat_lahir` varchar(45) DEFAULT NULL,
  `tanggal_lahir` date DEFAULT NULL,
  `ayah` varchar(45) DEFAULT NULL,
  `ibu` varchar(45) DEFAULT NULL,
  `alamat` text,
  `kabkot` varchar(45) DEFAULT NULL,
  `catatan_kesehatan` text,
  `nama_sekolah_id` int(11) NOT NULL,
  `program_keahlian_id` int(11) NOT NULL,
  `gol_darah_id` int(11) NOT NULL,
  `jenis_kelamin_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `siswa`
--

INSERT INTO `siswa` (`id`, `nama`, `foto`, `nomor_induk`, `tempat_lahir`, `tanggal_lahir`, `ayah`, `ibu`, `alamat`, `kabkot`, `catatan_kesehatan`, `nama_sekolah_id`, `program_keahlian_id`, `gol_darah_id`, `jenis_kelamin_id`) VALUES
(21, 'febri', NULL, '6153545', 'Bogor', NULL, 'jyet', 'tbuyb4', 'yb4u', 'ywb', NULL, 22, 6, 5, 0),
(23, 'siswa b', NULL, '3256464525', 'bogor', '2000-01-01', 'dtce', ' ete', 'yryec', 't3e', NULL, 22, 10, 5, 0),
(27, 'Ihsan Arif', 'PHOTO27.png', '0821309', 'Kota Tasikmalaya', '1992-10-02', 'ihsan', 'ihsan', 'Tegal Manggah No 10A RT 04 RW 06 Kelurahan Tegal Lega Kecamatan Bogor Tengah Kota Bogor (Masuk gang TK Mexindo, Posisi Rumah Setengah Tanjakan, sebelah kanan tanjakan ada Rumah Merah)', 'Bogor Tengah, Kota Bogor', NULL, 22, 5, 4, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `status_kehadiran`
--

CREATE TABLE IF NOT EXISTS `status_kehadiran` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `status_kehadiran`
--

INSERT INTO `status_kehadiran` (`id`, `nama`) VALUES
(1, 'Izin'),
(2, 'Sakit'),
(3, 'Alfa');

-- --------------------------------------------------------

--
-- Struktur dari tabel `unit`
--

CREATE TABLE IF NOT EXISTS `unit` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) DEFAULT NULL,
  `bidang` varchar(45) DEFAULT NULL,
  `alamat` text
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `unit`
--

INSERT INTO `unit` (`id`, `nama`, `bidang`, `alamat`) VALUES
(5, 'Direktorat Integrasi Data dan Sistem Informas', 'Sistem Informasi', 'Gedung Perpustakaan Lantai 2 Institut Pertanian Bogor Dramaga');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `jenis_user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `jenis_user_id`) VALUES
(0, NULL, NULL, 2),
(2, 'siswa@gmail.com', 'password', 2),
(3, 'pembimbing@gmail.com', 'password', 3),
(4, 'pembimbing.unit@gmail.com', 'password', 7),
(11, 'rahman@gmail.com', '12345678', 2),
(12, 'vini@gmail.com', 'vini1234567', 2),
(14, 'dina@gmail.com', 'dina', 2),
(15, 'mele@gmail.com', '12345678', 2),
(17, 'nana@gmail.com', 'abcdefghij', 2),
(18, 'ada@gmail.com', 'qwertyuio', 2),
(19, 'hikmah@gmail.com', 'hikmah', 2),
(20, 'salsa@gmail.com', 'salsa12345678', 2),
(21, 'febri@gmail.com', 'febri12345678', 2),
(23, 'siswab@admin.com', 'siswab12345', 2),
(25, 'siswaz@gmail.com', 'siswaz12345678', 2),
(27, 'ihsanarifr@hotmail.com', 'Rahman13', 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) unsigned NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) DEFAULT NULL,
  `email` varchar(100) NOT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `forgotten_password_code` varchar(40) DEFAULT NULL,
  `forgotten_password_time` int(11) unsigned DEFAULT NULL,
  `remember_code` varchar(40) DEFAULT NULL,
  `created_on` int(11) unsigned NOT NULL,
  `last_login` int(11) unsigned DEFAULT NULL,
  `active` tinyint(1) unsigned DEFAULT NULL,
  `first_name` varchar(50) DEFAULT NULL,
  `last_name` varchar(50) DEFAULT NULL,
  `company` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `ip_address`, `username`, `password`, `salt`, `email`, `activation_code`, `forgotten_password_code`, `forgotten_password_time`, `remember_code`, `created_on`, `last_login`, `active`, `first_name`, `last_name`, `company`, `phone`) VALUES
(1, '127.0.0.1', 'administrator', '$2a$07$SeBknntpZror9uyftVopmu61qg0ms8Qv1yV6FG.kQOSM.9QhmTo36', '', 'admin@admin.com', '', NULL, NULL, 'As034EW04Z0VnC/ZL4aqYe', 1268889823, 1485743242, 1, 'Admin', 'istrator', 'ADMIN', '0'),
(2, '127.0.0.1', 'siswa@gmail.com', '$2y$08$PAzcc2XEvEUCdTi0biefhetobZSv7v6iUWccceZcDDlvvbBgfTdFW', NULL, 'siswa@gmail.com', NULL, NULL, NULL, 'xdfbYkIM4pGSJCS5Ghsr4u', 1480452665, 1483944329, 1, 'siswa', 'siswa', 'siswa', '085222828740'),
(3, '127.0.0.1', 'pembimbing@gmail.com', '$2y$08$dNIbRJSDubhfsNquzD3VJ.zgTYHfrL6ID3Si38B2QOt7IsaTc9bQS', NULL, 'pembimbing@gmail.com', NULL, NULL, NULL, NULL, 1480452705, 1480475958, 1, 'Pembimbing Sekolah', 'pembimbing', 'pembimbing', '085222828740'),
(4, '127.0.0.1', 'pembimbing.unit@gmail.com', '$2y$08$4lQmX90l4UIpxNj7ew4bJ.jCNP8Gi3QZQ7k7EO3KAN/70wISRcj7m', NULL, 'pembimbing.unit@gmail.com', NULL, NULL, NULL, NULL, 1482209254, NULL, 1, 'Pembimbing Unit', 'pembimbing', 'DIDSI', '085222828740'),
(5, '::1', 'ihsan@gmail.com', '$2y$08$EhzefYwrJhj12C2YlaGWseAoWTBSp26ohg.j7SwaoqPIMkYvBQ7hG', NULL, 'ihsan@gmail.com', NULL, NULL, NULL, NULL, 1483676820, 1484884195, 1, 'a', 'a', 'a', '0'),
(7, '127.0.0.1', 'ihsan@ihsan.com', '$2y$08$BcxAhpTFz0Hq8XlbFJwawuSPdnj6qip/m6CgPSK.xRCdnPOOibEHe', NULL, 'ihsan@ihsan.com', NULL, NULL, NULL, NULL, 1483787100, 1483787236, 1, 'Ben', 'Edmunds', 'as', '085222828740'),
(8, '::1', 'tetst@gmail.com', '$2y$08$y4ssvgoX4ulWZeDyFvStW.bc9jZ5A9pRRFvH3wy28xwclAHrrlpIS', NULL, 'tetst@gmail.com', NULL, NULL, NULL, NULL, 1484189195, NULL, 1, 'q', NULL, NULL, NULL),
(9, '::1', 'bla@gmail.com', '$2y$08$dB6w5/EgV19MosBmabt5sOaAYcUVpVPL9MB07BJGhRo5Qmdo59aFO', NULL, 'bla@gmail.com', NULL, NULL, NULL, NULL, 1484189342, NULL, 1, 'bla', NULL, NULL, NULL),
(11, '::1', 'rahman@gmail.com', '$2y$08$tmr1.JdPnM6zwRzWDkwS8uyjYE/7wdxZhpQlFxLyM2abt43WCP.SW', NULL, 'rahman@gmail.com', NULL, NULL, NULL, NULL, 1484546473, NULL, 1, 'ANM2', NULL, NULL, NULL),
(12, '::1', 'vini@gmail.com', '$2y$08$fLaWMAE5d7EqU8HJxezzvuaAiiOpTJbIHFsfC1k5Yz/QGmCODyK3.', NULL, 'vini@gmail.com', NULL, NULL, NULL, NULL, 1484547719, NULL, 1, 'ggq', NULL, NULL, NULL),
(14, '::1', 'dina@gmail.com', '$2y$08$w3uiHGbsnOCKfBddBkJl3.8L7myNNayZl59HwStte9q74tvqWhXKy', NULL, 'dina@gmail.com', NULL, NULL, NULL, NULL, 1484706557, NULL, 1, 'dina anjani', NULL, NULL, NULL),
(15, '::1', 'mele@gmail.com', '$2y$08$GZC7HHEBNRQcYpbl8liN7usDHnQmUfV/85o5wgywlFcWR/1ib26Ne', NULL, 'mele@gmail.com', NULL, NULL, NULL, NULL, 1484711745, NULL, 1, 'melee', NULL, NULL, NULL),
(16, '::1', 'andini@gmail.com', '$2y$08$VXTCnFqDTD23g50zTBercOURxJb/bd9tFiYd.dG0nygsZRVJrEZKm', NULL, 'andini@gmail.com', NULL, NULL, NULL, NULL, 1484726345, NULL, 1, 'andini', NULL, NULL, NULL),
(17, '::1', 'nana@gmail.com', '$2y$08$QHntVUJDyr8xFCxsc1PWLerxjswzVS0JhXcHn7McNsGLu7qN8akXy', NULL, 'nana@gmail.com', NULL, NULL, NULL, NULL, 1484726554, NULL, 1, 'nananana', NULL, NULL, NULL),
(18, '::1', 'ada@gmail.com', '$2y$08$octBYRIcn415xGIc0FcgL.Va4M7AywKz7rbWs.B3sInwiPYrNVK6a', NULL, 'ada@gmail.com', NULL, NULL, NULL, NULL, 1484727059, NULL, 1, 'aaaa', NULL, NULL, NULL),
(19, '::1', 'hikmah@gmail.com', '$2y$08$ZKevfbX.FeY1XnW8cl8f/.JICk.BmQDdQ6g.Q7lsu74sk/HgoD7WO', NULL, 'hikmah@gmail.com', NULL, NULL, NULL, NULL, 1485305070, NULL, 1, 'RPL', NULL, NULL, NULL),
(20, '::1', 'salsa@gmail.com', '$2y$08$iU1Tca1HRuukSjQNPSLDIuNicV/RH7IdKBz6NsESovcXGOip2kNMC', NULL, 'salsa@gmail.com', NULL, NULL, NULL, NULL, 1485399482, NULL, 1, 'salsa', NULL, NULL, NULL),
(21, '::1', 'febri@gmail.com', '$2y$08$NxZuguAKJ/N3qc.XDftHtebMKOIq5ewEiD54XrPNjLKcXeOYLuQpu', NULL, 'febri@gmail.com', NULL, NULL, NULL, NULL, 1485404240, NULL, 1, 'febri', NULL, NULL, NULL),
(23, '::1', 'siswab@admin.com', '$2y$08$OOuuRhcGNnLm1i7Acz7VGuFCx6x0mrctxPt2MpXsOYrv82./U59zS', NULL, 'siswab@admin.com', NULL, NULL, NULL, NULL, 1485414864, 1485509175, 1, 'siswa b', NULL, NULL, NULL),
(25, '::1', 'siswaz@gmail.com', '$2y$08$LIG18zWAT4U495VjWlr4R.ukxeqdEbtz8BF5.erkotyFWtPX5209q', NULL, 'siswaz@gmail.com', NULL, NULL, NULL, NULL, 1485499088, NULL, 1, 'siswaz', NULL, NULL, NULL),
(27, '127.0.0.1', 'ihsanarifr@hotmail.com', '$2y$08$Zsv7ZBY2RxPvWSrr7DbQEOegwmAVnBqYKE/xnOZPEBy/9foI9oca.', NULL, 'ihsanarifr@hotmail.com', NULL, NULL, NULL, NULL, 1485504974, 1485512077, 1, 'Ihsan Arif', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `users_groups`
--

CREATE TABLE IF NOT EXISTS `users_groups` (
  `id` int(11) unsigned NOT NULL,
  `user_id` int(11) unsigned NOT NULL,
  `group_id` mediumint(8) unsigned NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `users_groups`
--

INSERT INTO `users_groups` (`id`, `user_id`, `group_id`) VALUES
(1, 1, 1),
(9, 2, 2),
(6, 3, 3),
(16, 5, 2),
(14, 7, 1),
(17, 8, 2),
(18, 9, 2),
(20, 11, 2),
(21, 12, 2),
(23, 14, 2),
(24, 15, 2),
(25, 17, 2),
(26, 18, 2),
(27, 19, 2),
(28, 20, 2),
(29, 21, 2),
(31, 23, 2),
(33, 25, 2),
(35, 27, 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `absensi`
--
ALTER TABLE `absensi`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_absensi_prakerin_siswa1_idx` (`prakerin_siswa_id`),
  ADD KEY `fk_absensi_status_kehadiran1_idx` (`status_kehadiran_id`);

--
-- Indexes for table `aspek_penilaian`
--
ALTER TABLE `aspek_penilaian`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_aspek_penilaian_nama_sekolah1_idx` (`nama_sekolah_id`),
  ADD KEY `fk_aspek_penilaian_kelompok_penilaian1_idx` (`kelompok_penilaian_id`);

--
-- Indexes for table `gol_darah`
--
ALTER TABLE `gol_darah`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `groups`
--
ALTER TABLE `groups`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jenis_kelamin`
--
ALTER TABLE `jenis_kelamin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `jenis_user`
--
ALTER TABLE `jenis_user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kegiatan`
--
ALTER TABLE `kegiatan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_kegiatan_prakerin_siswa1_idx` (`prakerin_siswa_id`);

--
-- Indexes for table `kelas`
--
ALTER TABLE `kelas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kelompok_penilaian`
--
ALTER TABLE `kelompok_penilaian`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login_attempts`
--
ALTER TABLE `login_attempts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `nama_sekolah`
--
ALTER TABLE `nama_sekolah`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pembimbing_sekolah`
--
ALTER TABLE `pembimbing_sekolah`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_pembimbing_sekolah_user1_idx` (`id`),
  ADD KEY `fk_pembimbing_sekolah_nama_sekolah1_idx` (`nama_sekolah_id`);

--
-- Indexes for table `pembimbing_unit`
--
ALTER TABLE `pembimbing_unit`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_pembimbing_unit_user1_idx` (`id`),
  ADD KEY `fk_pembimbing_unit_unit1_idx` (`unit_id`);

--
-- Indexes for table `penilaian`
--
ALTER TABLE `penilaian`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_penilaian_prakerin_siswa1_idx` (`prakerin_siswa_id`),
  ADD KEY `fk_penilaian_aspek_penilaian1_idx` (`aspek_penilaian_id`);

--
-- Indexes for table `permasalahan`
--
ALTER TABLE `permasalahan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_permasalahan_prakerin_siswa1_idx` (`prakerin_siswa_id`);

--
-- Indexes for table `prakerin_siswa`
--
ALTER TABLE `prakerin_siswa`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_prakerin_siswa_unit1_idx` (`unit_id`),
  ADD KEY `fk_prakerin_siswa_kelas1_idx` (`kelas_id`),
  ADD KEY `fk_prakerin_siswa_siswa1_idx` (`siswa_id`),
  ADD KEY `fk_prakerin_siswa_pembimbing_unit1_idx` (`pembimbing_unit_id`),
  ADD KEY `fk_prakerin_siswa_pembimbing_sekolah1_idx` (`pembimbing_sekolah_id`);

--
-- Indexes for table `program_keahlian`
--
ALTER TABLE `program_keahlian`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rencana_kegiatan`
--
ALTER TABLE `rencana_kegiatan`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_rencana_kegiatan_prakerin_siswa1_idx` (`prakerin_siswa_id`);

--
-- Indexes for table `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_siswa_nama_sekolah_idx` (`nama_sekolah_id`),
  ADD KEY `fk_siswa_program_keahlian1_idx` (`program_keahlian_id`),
  ADD KEY `fk_siswa_gol_darah1_idx` (`gol_darah_id`),
  ADD KEY `fk_siswa_user1_idx` (`id`);

--
-- Indexes for table `status_kehadiran`
--
ALTER TABLE `status_kehadiran`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `unit`
--
ALTER TABLE `unit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_user_jenis_user1_idx` (`jenis_user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_groups`
--
ALTER TABLE `users_groups`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uc_users_groups` (`user_id`,`group_id`),
  ADD KEY `fk_users_groups_users1_idx` (`user_id`),
  ADD KEY `fk_users_groups_groups1_idx` (`group_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `absensi`
--
ALTER TABLE `absensi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `aspek_penilaian`
--
ALTER TABLE `aspek_penilaian`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `gol_darah`
--
ALTER TABLE `gol_darah`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `groups`
--
ALTER TABLE `groups`
  MODIFY `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `jenis_kelamin`
--
ALTER TABLE `jenis_kelamin`
  MODIFY `id` int(1) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `jenis_user`
--
ALTER TABLE `jenis_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `kegiatan`
--
ALTER TABLE `kegiatan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `kelas`
--
ALTER TABLE `kelas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `kelompok_penilaian`
--
ALTER TABLE `kelompok_penilaian`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `login_attempts`
--
ALTER TABLE `login_attempts`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `nama_sekolah`
--
ALTER TABLE `nama_sekolah`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `penilaian`
--
ALTER TABLE `penilaian`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `permasalahan`
--
ALTER TABLE `permasalahan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `prakerin_siswa`
--
ALTER TABLE `prakerin_siswa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT for table `program_keahlian`
--
ALTER TABLE `program_keahlian`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `rencana_kegiatan`
--
ALTER TABLE `rencana_kegiatan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `status_kehadiran`
--
ALTER TABLE `status_kehadiran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `unit`
--
ALTER TABLE `unit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `users_groups`
--
ALTER TABLE `users_groups`
  MODIFY `id` int(11) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=36;
--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `absensi`
--
ALTER TABLE `absensi`
  ADD CONSTRAINT `fk_absensi_prakerin_siswa1` FOREIGN KEY (`prakerin_siswa_id`) REFERENCES `prakerin_siswa` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_absensi_status_kehadiran1` FOREIGN KEY (`status_kehadiran_id`) REFERENCES `status_kehadiran` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `aspek_penilaian`
--
ALTER TABLE `aspek_penilaian`
  ADD CONSTRAINT `fk_aspek_penilaian_kelompok_penilaian1` FOREIGN KEY (`kelompok_penilaian_id`) REFERENCES `kelompok_penilaian` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_aspek_penilaian_nama_sekolah1` FOREIGN KEY (`nama_sekolah_id`) REFERENCES `nama_sekolah` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `kegiatan`
--
ALTER TABLE `kegiatan`
  ADD CONSTRAINT `fk_kegiatan_prakerin_siswa1` FOREIGN KEY (`prakerin_siswa_id`) REFERENCES `prakerin_siswa` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `pembimbing_sekolah`
--
ALTER TABLE `pembimbing_sekolah`
  ADD CONSTRAINT `fk_pembimbing_sekolah_nama_sekolah1` FOREIGN KEY (`nama_sekolah_id`) REFERENCES `nama_sekolah` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_pembimbing_sekolah_user1` FOREIGN KEY (`id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `pembimbing_unit`
--
ALTER TABLE `pembimbing_unit`
  ADD CONSTRAINT `fk_pembimbing_unit_unit1` FOREIGN KEY (`unit_id`) REFERENCES `unit` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_pembimbing_unit_user1` FOREIGN KEY (`id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `penilaian`
--
ALTER TABLE `penilaian`
  ADD CONSTRAINT `fk_penilaian_aspek_penilaian1` FOREIGN KEY (`aspek_penilaian_id`) REFERENCES `aspek_penilaian` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_penilaian_prakerin_siswa1` FOREIGN KEY (`prakerin_siswa_id`) REFERENCES `prakerin_siswa` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `permasalahan`
--
ALTER TABLE `permasalahan`
  ADD CONSTRAINT `fk_permasalahan_prakerin_siswa1` FOREIGN KEY (`prakerin_siswa_id`) REFERENCES `prakerin_siswa` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `prakerin_siswa`
--
ALTER TABLE `prakerin_siswa`
  ADD CONSTRAINT `fk_prakerin_siswa_kelas1` FOREIGN KEY (`kelas_id`) REFERENCES `kelas` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_prakerin_siswa_pembimbing_sekolah1` FOREIGN KEY (`pembimbing_sekolah_id`) REFERENCES `pembimbing_sekolah` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_prakerin_siswa_pembimbing_unit1` FOREIGN KEY (`pembimbing_unit_id`) REFERENCES `pembimbing_unit` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_prakerin_siswa_siswa1` FOREIGN KEY (`siswa_id`) REFERENCES `siswa` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_prakerin_siswa_unit1` FOREIGN KEY (`unit_id`) REFERENCES `unit` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `rencana_kegiatan`
--
ALTER TABLE `rencana_kegiatan`
  ADD CONSTRAINT `fk_rencana_kegiatan_prakerin_siswa1` FOREIGN KEY (`prakerin_siswa_id`) REFERENCES `prakerin_siswa` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `siswa`
--
ALTER TABLE `siswa`
  ADD CONSTRAINT `fk_siswa_gol_darah1` FOREIGN KEY (`gol_darah_id`) REFERENCES `gol_darah` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_siswa_nama_sekolah` FOREIGN KEY (`nama_sekolah_id`) REFERENCES `nama_sekolah` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_siswa_program_keahlian1` FOREIGN KEY (`program_keahlian_id`) REFERENCES `program_keahlian` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_siswa_user1` FOREIGN KEY (`id`) REFERENCES `user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `fk_user_jenis_user1` FOREIGN KEY (`jenis_user_id`) REFERENCES `jenis_user` (`id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `users_groups`
--
ALTER TABLE `users_groups`
  ADD CONSTRAINT `fk_users_groups_groups1` FOREIGN KEY (`group_id`) REFERENCES `groups` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_users_groups_users1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE NO ACTION;
--
-- Database: `blog`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00'
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `posts`
--

INSERT INTO `posts` (`id`, `title`, `image`, `content`, `created_at`, `updated_at`) VALUES
(1, '5 Habits that can improve your life', '750x300.png', 'Read every day', '2019-05-13 09:17:01', '0000-00-00 00:00:00'),
(2, 'Second post on LifeBlog', ' 750x300.png', 'This is the body of the second post on this site', '2019-05-13 09:17:01', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;--
-- Database: `cdcol`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `cds`
--

CREATE TABLE IF NOT EXISTS `cds` (
  `titel` varchar(200) COLLATE latin1_general_ci DEFAULT NULL,
  `interpret` varchar(200) COLLATE latin1_general_ci DEFAULT NULL,
  `jahr` int(11) DEFAULT NULL,
  `id` bigint(20) unsigned NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `cds`
--

INSERT INTO `cds` (`titel`, `interpret`, `jahr`, `id`) VALUES
('Beauty', 'Ryuichi Sakamoto', 1990, 1),
('Goodbye Country (Hello Nightclub)', 'Groove Armada', 2001, 4),
('Glee', 'Bran Van 3000', 1997, 5);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cds`
--
ALTER TABLE `cds`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cds`
--
ALTER TABLE `cds`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;--
-- Database: `chat`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `drzchat`
--

CREATE TABLE IF NOT EXISTS `drzchat` (
  `nomor` int(3) NOT NULL,
  `nama` varchar(20) NOT NULL,
  `pesan` varchar(200) NOT NULL,
  `waktu` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `drzchat`
--

INSERT INTO `drzchat` (`nomor`, `nama`, `pesan`, `waktu`) VALUES
(1, 'Admin', '\r\nbergabung dalam chat', '06:13'),
(2, 'Admin', '\r\nbergabung dalam chat', '06:22'),
(3, 'Admin', '\r\nbergabung dalam chat', '06:23'),
(4, 'Admin', '\r\nbergabung dalam chat', '06:24'),
(5, 'Admin', '\r\nbergabung dalam chat', '06:51'),
(6, 'Admin', '\r\nbergabung dalam chat', '09:56'),
(7, 'Admin', '\r\nbergabung dalam chat', '09:56'),
(8, 'Admin', '\r\nbergabung dalam chat', '10:14'),
(9, 'Admin', '\r\nbergabung dalam chat', '10:23'),
(10, 'Admin', '\r\nbergabung dalam chat', '10:29'),
(11, 'Admin', '\r\nbergabung dalam chat', '10:33'),
(12, 'Admin', '\r\nbergabung dalam chat', '10:47'),
(13, 'Admin', '\r\nbergabung dalam chat', '10:48'),
(14, 'Admin', '\r\nbergabung dalam chat', '10:48'),
(15, 'Admin', '\r\nbergabung dalam chat', '10:48'),
(16, 'Admin', '\r\nbergabung dalam chat', '10:48'),
(17, 'Admin', '\r\nbergabung dalam chat', '10:51'),
(18, 'Admin', '\r\nbergabung dalam chat', '10:51'),
(19, 'Admin', '\r\nbergabung dalam chat', '10:56'),
(20, 'Admin', '\r\nbergabung dalam chat', '10:56'),
(21, 'Admin', '\r\nbergabung dalam chat', '10:56'),
(22, 'Admin', '\r\nbergabung dalam chat', '10:59'),
(23, 'Admin', '\r\nbergabung dalam chat', '11:13'),
(24, 'Admin', '\r\nbergabung dalam chat', '11:13');

-- --------------------------------------------------------

--
-- Struktur dari tabel `message`
--

CREATE TABLE IF NOT EXISTS `message` (
  `message_id` int(11) NOT NULL,
  `chat_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `user_name` varchar(64) DEFAULT NULL,
  `message` text NOT NULL,
  `post_time` datetime DEFAULT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `message`
--

INSERT INTO `message` (`message_id`, `chat_id`, `user_id`, `user_name`, `message`, `post_time`) VALUES
(1, 1, 1, 'fajri', 'Hallo Apa Kabar?', '2019-11-13 17:03:00'),
(2, 1, 2, 'anya', 'Kabar Baik', '2019-11-13 17:04:00'),
(3, 1, 1, 'fajri', 'Lagi Dimana?', '2019-11-13 17:08:00'),
(4, 1, 2, 'anya', 'Lagi di Tegal', '2019-11-13 17:09:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `drzchat`
--
ALTER TABLE `drzchat`
  ADD PRIMARY KEY (`nomor`);

--
-- Indexes for table `message`
--
ALTER TABLE `message`
  ADD PRIMARY KEY (`message_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `drzchat`
--
ALTER TABLE `drzchat`
  MODIFY `nomor` int(3) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `message`
--
ALTER TABLE `message`
  MODIFY `message_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;--
-- Database: `crud_mahasiswa`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `crud`
--

CREATE TABLE IF NOT EXISTS `crud` (
  `nama` varchar(50) NOT NULL,
  `nim` varchar(20) NOT NULL,
  `no_hp` varchar(25) NOT NULL,
  `kelas` varchar(20) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `crud`
--

INSERT INTO `crud` (`nama`, `nim`, `no_hp`, `kelas`, `alamat`) VALUES
('rocky nurdiansyah', '17090025', '0856782120', '5C', 'Slawi');
--
-- Database: `data_penyandian`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `akun_pelanggan`
--

CREATE TABLE IF NOT EXISTS `akun_pelanggan` (
  `id_pel` varchar(10) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `password_recovery` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `data_piutang`
--

CREATE TABLE IF NOT EXISTS `data_piutang` (
  `id_pel` varchar(10) NOT NULL,
  `jumlah_hutang` varchar(25) NOT NULL,
  `jumlah_piutang` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pelanggan`
--

CREATE TABLE IF NOT EXISTS `pelanggan` (
  `id_pel` varchar(10) NOT NULL,
  `nama_pel` varchar(255) NOT NULL,
  `no_hp` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL,
  `email` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` varchar(10) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Database: `db_kontak`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `teman`
--

CREATE TABLE IF NOT EXISTS `teman` (
  `id` int(11) NOT NULL,
  `nama` varchar(45) NOT NULL,
  `email` varchar(100) NOT NULL,
  `website` varchar(50) NOT NULL,
  `alamat` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `teman`
--

INSERT INTO `teman` (`id`, `nama`, `email`, `website`, `alamat`) VALUES
(1, 'rocky', 'rocky@gmail.com', 'rocky.com', 'tegal'),
(3, 'Ani', 'ani@gmail.com', 'http://poltektegal.ac.id', 'Tegal'),
(4, 'Ani', 'ani@gmail.com', 'http://poltektegal.ac.id', 'Tegal');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `teman`
--
ALTER TABLE `teman`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `teman`
--
ALTER TABLE `teman`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;--
-- Database: `db_terate`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(10) NOT NULL,
  `password` varchar(10) NOT NULL,
  `nama` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `nama`) VALUES
(1, 'admin', 'admin', 'jason');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kabupaten`
--

CREATE TABLE IF NOT EXISTS `kabupaten` (
  `id` int(11) NOT NULL,
  `kabupaten` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kabupaten`
--

INSERT INTO `kabupaten` (`id`, `kabupaten`) VALUES
(1, 'nganjuk');

-- --------------------------------------------------------

--
-- Struktur dari tabel `katalog`
--

CREATE TABLE IF NOT EXISTS `katalog` (
  `id_katalog` int(11) NOT NULL,
  `nama_katalog` varchar(10) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `katalog`
--

INSERT INTO `katalog` (`id_katalog`, `nama_katalog`) VALUES
(13, 'jaket'),
(14, 'sepatu'),
(15, 'kaos'),
(16, 'jam tangan'),
(17, 'celana'),
(18, 'topi');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kelompok`
--

CREATE TABLE IF NOT EXISTS `kelompok` (
  `id` int(11) NOT NULL,
  `nama` varchar(15) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kelompok`
--

INSERT INTO `kelompok` (`id`, `nama`) VALUES
(1, 'elektronik'),
(2, 'pakaian'),
(6, ''),
(7, 'rumah tangga'),
(8, 'ajke'),
(9, 'ddd'),
(10, 'assesoris'),
(11, 'olahraga');

-- --------------------------------------------------------

--
-- Struktur dari tabel `konfirmasi`
--

CREATE TABLE IF NOT EXISTS `konfirmasi` (
  `id` int(11) NOT NULL,
  `kode_pembelian` varchar(15) NOT NULL,
  `nama_bank` varchar(10) NOT NULL,
  `tgl` date NOT NULL,
  `pesan` text NOT NULL,
  `gambar` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `konfirmasi`
--

INSERT INTO `konfirmasi` (`id`, `kode_pembelian`, `nama_bank`, `tgl`, `pesan`, `gambar`) VALUES
(1, '347', 'BCA', '2016-11-29', 'admin/gambar/hider.jpg', 'Saya Sudah Ko'),
(2, '347', 'BRI', '2016-11-29', 'admin/gambar/hider.jpg', 'ND'),
(3, '347', 'BRI', '2016-11-29', 'sjsjs', 'admin/gambar/hider.jpg'),
(4, '347', 'BRI', '2016-11-29', 'sjsjs', 'admin/gambar/hider.jpg'),
(5, '347', 'BRI', '2016-11-29', 'sjsjs', 'admin/gambar/hider.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pembeli`
--

CREATE TABLE IF NOT EXISTS `pembeli` (
  `id_pembeli` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(50) NOT NULL,
  `alamat` varchar(200) NOT NULL,
  `provinsi` varchar(50) NOT NULL,
  `kabupaten` varchar(50) NOT NULL,
  `kecamatan` varchar(50) NOT NULL,
  `kode_pos` varchar(10) NOT NULL,
  `no_telp` varchar(16) NOT NULL,
  `estimasi` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pembeli`
--

INSERT INTO `pembeli` (`id_pembeli`, `username`, `nama_lengkap`, `email`, `password`, `alamat`, `provinsi`, `kabupaten`, `kecamatan`, `kode_pos`, `no_telp`, `estimasi`) VALUES
(1, 'afiq', '', '', '1234', 'jl jati baron nganjuk jawa timur', 'jawa timur', 'nganjuk', 'baron', '', '', 19000),
(2, 'bagus_fever', 'Bagus Dwiky Wicaksono', 'bagusbieber1922@gmail.com', 'bagusfever', 'Dusun Gebangsiwil RT 03 RW 03 ', 'Jawa Timur', 'Nganjuk', 'Nganjuk', '829222', '05608397972', 0),
(3, 'bagus_fever', 'Bagus', 'bagus@yahoo.co.id', 'bagus1922', '', '--Provinsi--', '--Kota--', '--Kecematan--', '', '', 0),
(4, 'baguspsht', 'Bagus Dwiky Wicaksono', 'bagusbieber1922@gmail.com', 'bagus1922', 'Dusun Gabangsiwil Desa Bukur RT 03 RW 03', 'Jawa Timur', 'Nganjuk', 'Patianrowo', '927272', '085608397972', 0),
(5, 'eva', 'eva', 'eva@gmail.com', 'eva1922', 'desa karang tengah rt 02 rw 08', 'Jawa Timur', 'Nganjuk', 'Patianrowo', '88373', '0833736333', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk`
--

CREATE TABLE IF NOT EXISTS `produk` (
  `id` int(11) NOT NULL,
  `nama_produk` varchar(100) NOT NULL,
  `harga` int(11) NOT NULL,
  `gambar` varchar(200) NOT NULL,
  `kelompok` varchar(15) NOT NULL,
  `katalog` varchar(10) NOT NULL,
  `diskon` varchar(10) NOT NULL,
  `ket` varchar(2000) NOT NULL,
  `qty` int(11) NOT NULL,
  `kategori` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `produk`
--

INSERT INTO `produk` (`id`, `nama_produk`, `harga`, `gambar`, `kelompok`, `katalog`, `diskon`, `ket`, `qty`, `kategori`) VALUES
(9, 'LG led tv 20"', 3000000, 'gambar/3.jpg', 'elektronik', '', '', 'LG 32 inch LED TV 32LN-4900, hadir dengan desain frame dan bezelnya tipis. LED TV ini memiliki Smart Energy Saving \r\n(SES) sehingga dapat menghemat 30% energi. Smart Energy Saving (SES) memiliki beragam fungsi seperti fungsi standby \r\nmode zero membuat TV Anda tidak menggunakan listrik saat standby.', -1, 'Elektronik'),
(10, 'LG led tv 90"', 5000000, 'gambar/6.jpg', 'elektronik', '', '', 'TV LED berukuran 90 inch yang memiliki resolusi Full HD 1080 (1920 x 1080) dengan rasio 16:9 serta dilengkapi \r\nDolby Digital. KLV32EX43A disupport dengan teknologi BRAVIA Engine 3, yang memiliki kemampuan menganalisis setiap \r\ngambar atau adegan, dan mengolahnya sehingga memberikan warna dan kontras yang optimal.', 53, 'Elektronik'),
(12, 'SHARP LED TV 24 inch LC-24DC50M', 4000000, 'gambar/4.jpg', 'elektronik', '', '', 'SHARP LED TV 24 inch LC-24DC50M, LED TV Full HD berukuran 24 inch yang mengedepankan teknologi yang ramah lingkungan. \r\nDengan fitur OPC, konsumsi listrik dapat diatur otomatis sesuai dengan pencahayaan ruangan sehingga konsumsi \r\nlistrik SHARP AQUOS menjadi hemat. Ditunjang dengan SRS TruSurrond HD and Bass Enhancer yaitu Audio speaker \r\nberkualitas SRS TruSurround High Definition dengan suara bass yang mengagumkan.\r\n', 55, 'Elektronik'),
(13, 'Nikon Camera Mirrorless S1 10-30 Red', 5000000, 'gambar/5.jpg', 'elektronik', '', '', 'Nikon Camera Mirrorless S1 10-30 adalah kamera mirrorless yang didesain compact dan stylish dan dilengkapi dengan \r\nInterchangeable Lens System 10 - 30 mm. Kamera dengan teknologi CMOS sensor Nikon CX-format ini ditunjang dengan \r\ndisplay TFT LCD 3 inch, kemampuan full HD dan resolusi 10.1 untuk memudahkan Anda berekspresi melalui hasil jepretan \r\nAnda.\r\n', 75, 'Elektronik'),
(15, 'Canon EOS 7D KIT 18-135mm', 6000000, 'gambar/5.jpg', 'elektronik', '', '', 'Canon EOS 7D KIT 18-135 mm yang didesain compact untuk kenyamanan Anda juga didukung dengan performa maksimal. \r\nKamera 18 MP ini dilengkapi layar Clear View II LCD 3 inch, Integrated Speedlite Transmitter dan fitur EOS Movie \r\nuntuk merekam Full HD movie dengan full manual control and selectable frame rates.', 65, 'Elektronik'),
(18, 'Samsung Galaxy Note 8.0 - N5100 Brown', 9000000, 'gambar/1f0.jpg', 'elektronik', '', '', 'Samsung Galaxy Note 8.0 - N5100 Brown, hadir dengan layar sebesar 8 inch dengan resolusi 1280x800 dan tidak \r\nhanya sekedar tablet Android yang terhubung dengan jaringan internet, Samsung Galaxy Note 8.0 bahkan bisa\r\nmelakukan panggilan telepon dan SMS. Galaxy Note 8.0 diperkuat dengan prosesor Quad Core 1.6 GHz Cortex-A9, \r\nOS Android Jelly Bean V4.1.2, memori internal 16 GB, dan dual kamera (kamera depan 5 MP, dan kamera belakang 1.3 MP).\r\nUntuk konektivitas Galaxy Note 8.0 sudah didukung Wi-Fi, Wi-Fi hotspot, dan Bluetooth V4.0.', 3, 'Elektronik'),
(19, 'Sony Xperia V LT25i White', 5300000, 'gambar/wdaw.jpg', 'elektronik', '', '', 'Sony Xperia V LT25i, hadir dengan desain stylish, dan unik. Smartphone ini juga ditunjang dengan \r\nOS Android Ice Cream Sandwich v4.0 dan prosesor Dual-core 1.5 GHz Qualcomm MSM8960 Snapdragon, serta Adreno 225. \r\nDilengkapi dengan layar touchscreen 4,3 inch, kamera 13 MP dengan autofocus dan LED flash, memori internal 8 GB \r\ndengan slot kartu memori serta konektivitas Wi-Fi 802.11 b/g/n, dengan kemampuan Wi-Fi Direct, DLNA, Wi-Fi hotspot, \r\nBluetooth v4.0, dan NFC. Xperia V LT25i ini juga mampu bertahan di medan ekstrim karena memiliki fitur water proof \r\ndan water resistant, sehingga sangat cocok untuk Anda yang suka berpetualang.', 71, 'Elektronik'),
(20, 'Kaos PSHT', 90000, 'kaos', '8', 'gambar/192', '', 'sjjsssssssssssssssss', 0, 'Pakaian'),
(21, 'Kaos PSHT', 90000, 'gambar/192.jpg', 'pakaian', 'kaos', '', 'sjjsssssssssssssssssddd', 3, 'Pakaian'),
(22, 'kaos psht terate hijau', 90000, 'gambar/TERA IJO.jpg', 'kaos', '', '', 'Kaos KaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaos', 30, 'kaos psht'),
(23, 'kaos psht terate hijau', 90000, 'gambar/TERA IJO.jpg', 'kaos', '', '', 'Kaos KaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaos', 30, 'kaos psht'),
(24, 'kaos psht tendangan t', 90000, 'gambar/10687026_538818476251791_5192189108266288028_n.jpg', 'pakaian', 'kaos', '', 'KaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaosKaos', 7, 'kaos psht'),
(26, 'jaket holding sweter  psht ', 120000, 'gambar/Alan-Walker.jpg', 'pakaian', 'jaket', '', 'jaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaket', 30, 'jaket dj'),
(27, 'kaos silat psht terate', 120000, 'gambar/Kaos PSHT Kode SH 50 Persaudaraan setia hati Terate  Kaos Psht Kode Sh keren Persaudaraan Setia Hati Terate.jpg', 'pakaian', 'kaos', '10%', 'jaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaket', 26, 'kaos psht'),
(28, '', 0, 'gambar/', '', '', '10%', '', 0, ''),
(29, 'kaos silat psht terate 1922', 100000, 'gambar/Kaos_PSHT_Kode_SH_43_Persaudaraan_setia_hati_Terate.jpg', 'pakaian', 'kaos', '10%', 'jaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaket', 9, 'kaos psht'),
(30, 'sepatu nike sport', 300000, 'gambar/nav_img.jpg', 'olahraga', 'sepatu', '', 'jaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaket', 10, 'sepatu nike'),
(31, 'sepatu nike sport', 300000, 'gambar/pic3.jpg', 'olahraga', 'sepatu', '', 'jaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaket', 10, 'sepatu nike'),
(32, 'sepatu nike sport', 300000, 'gambar/pic5.jpg', 'olahraga', 'sepatu', '', 'jaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaket', 10, 'sepatu nike'),
(33, 'sepatu nike sport', 300000, 'gambar/banner1.jpg', 'olahraga', 'sepatu', '', 'jaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaketjaket', 9, 'sepatu nike');

-- --------------------------------------------------------

--
-- Struktur dari tabel `produk_temp`
--

CREATE TABLE IF NOT EXISTS `produk_temp` (
  `id` int(11) NOT NULL,
  `id_pembeli` int(11) NOT NULL,
  `id_produk` int(11) NOT NULL,
  `nama_produk` varchar(200) NOT NULL,
  `harga` int(11) NOT NULL,
  `total_harga` int(11) NOT NULL,
  `gambar` varchar(200) NOT NULL,
  `qty_beli` int(11) NOT NULL,
  `qty_asli` int(11) NOT NULL,
  `kategori` varchar(200) NOT NULL,
  `ket` int(11) NOT NULL,
  `jasa_pengiriman` varchar(15) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `produk_temp`
--

INSERT INTO `produk_temp` (`id`, `id_pembeli`, `id_produk`, `nama_produk`, `harga`, `total_harga`, `gambar`, `qty_beli`, `qty_asli`, `kategori`, `ket`, `jasa_pengiriman`) VALUES
(50, 0, 18, 'Samsung Galaxy Note 8.0 - N5100 Brown', 9000000, 9000000, 'gambar/1f0.jpg', 1, 6, 'Elektronik', 0, ''),
(51, 0, 33, 'sepatu nike sport', 300000, 300000, 'gambar/banner1.jpg', 1, 10, 'sepatu nike', 0, '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `selesai`
--

CREATE TABLE IF NOT EXISTS `selesai` (
  `id` int(11) NOT NULL,
  `id_pembeli` int(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `jumlah_barang` int(11) NOT NULL,
  `jumlah_bayar` int(11) NOT NULL,
  `tanggal_beli` varchar(50) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `kabupaten` varchar(20) NOT NULL,
  `kecamatan` varchar(20) NOT NULL,
  `provinsi` varchar(20) NOT NULL,
  `kode_pos` varchar(10) NOT NULL,
  `no_telp` varchar(15) NOT NULL,
  `jasa_pengiriman` varchar(20) NOT NULL,
  `konfir` varchar(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `selesai`
--

INSERT INTO `selesai` (`id`, `id_pembeli`, `nama`, `jumlah_barang`, `jumlah_bayar`, `tanggal_beli`, `alamat`, `kabupaten`, `kecamatan`, `provinsi`, `kode_pos`, `no_telp`, `jasa_pengiriman`, `konfir`) VALUES
(14, 1, 'afiq', 1, 6000000, '29-11-2016', 'jl jati baron nganjuk jawa timur', 'nganjuk', 'baron', 'jawa timur', '', '', '', 'Y'),
(15, 1, 'afiq', 1, 5000000, '29-11-2016', 'jl jati baron nganjuk jawa timur', 'nganjuk', 'baron', 'jawa timur', '', '', '', 'N'),
(16, 1, 'afiq', 1, 6000000, '29-11-2016', 'jl jati baron nganjuk jawa timur', 'nganjuk', 'baron', 'jawa timur', '', '', '', 'N'),
(17, 1, 'afiq', 1, 9000000, '29-11-2016', 'jl jati baron nganjuk jawa timur', 'nganjuk', 'baron', 'jawa timur', '', '', '', 'N'),
(18, 1, 'afiq', 1, 5300000, '29-11-2016', 'jl jati baron nganjuk jawa timur', 'nganjuk', 'baron', 'jawa timur', '', '', '', 'N'),
(19, 5, 'eva', 1, 9000000, '29-11-2016', 'desa karang tengah rt 02 rw 08', 'Nganjuk', 'Patianrowo', 'Jawa Timur', '88373', '0833736333', '', 'N'),
(20, 5, 'eva', 2, 10000000, '29-11-2016', 'desa karang tengah rt 02 rw 08', 'Nganjuk', 'Patianrowo', 'Jawa Timur', '88373', '0833736333', 'POS REGULER', 'N'),
(21, 5, 'eva', 1, 8000000, '29-11-2016', 'desa karang tengah rt 02 rw 08', 'Nganjuk', 'Patianrowo', 'Jawa Timur', '88373', '0833736333', 'POS KILAT', 'N');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kabupaten`
--
ALTER TABLE `kabupaten`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `katalog`
--
ALTER TABLE `katalog`
  ADD PRIMARY KEY (`id_katalog`);

--
-- Indexes for table `kelompok`
--
ALTER TABLE `kelompok`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `konfirmasi`
--
ALTER TABLE `konfirmasi`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pembeli`
--
ALTER TABLE `pembeli`
  ADD PRIMARY KEY (`id_pembeli`);

--
-- Indexes for table `produk`
--
ALTER TABLE `produk`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `produk_temp`
--
ALTER TABLE `produk_temp`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `selesai`
--
ALTER TABLE `selesai`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `kabupaten`
--
ALTER TABLE `kabupaten`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `katalog`
--
ALTER TABLE `katalog`
  MODIFY `id_katalog` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `kelompok`
--
ALTER TABLE `kelompok`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `konfirmasi`
--
ALTER TABLE `konfirmasi`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `pembeli`
--
ALTER TABLE `pembeli`
  MODIFY `id_pembeli` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `produk`
--
ALTER TABLE `produk`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=34;
--
-- AUTO_INCREMENT for table `produk_temp`
--
ALTER TABLE `produk_temp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=52;
--
-- AUTO_INCREMENT for table `selesai`
--
ALTER TABLE `selesai`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=22;--
-- Database: `db_websisteminformasi`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `mahasiswa`
--

CREATE TABLE IF NOT EXISTS `mahasiswa` (
  `nim` varchar(8) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `prodi` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `mahasiswa`
--

INSERT INTO `mahasiswa` (`nim`, `nama`, `prodi`) VALUES
('17090025', 'rocky', 'teknik informatika');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`nim`);
--
-- Database: `db_websistemmusik`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `musik`
--

CREATE TABLE IF NOT EXISTS `musik` (
  `id` varchar(8) NOT NULL,
  `nama alat musik` varchar(50) NOT NULL,
  `jenis alat musik` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `musik`
--

INSERT INTO `musik` (`id`, `nama alat musik`, `jenis alat musik`) VALUES
('1', 'gitar', 'gitar akustik'),
('2', 'gitar', 'gitar listrik');
--
-- Database: `dbpasien`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `login`
--

INSERT INTO `login` (`username`, `password`) VALUES
('riki', '62dd7e80fdfcb966cac9c849268c61d9');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tabinputdata`
--

CREATE TABLE IF NOT EXISTS `tabinputdata` (
  `kodepasien` varchar(20) NOT NULL,
  `nama` varchar(40) NOT NULL,
  `usia` varchar(5) NOT NULL,
  `jeniskelamin` varchar(10) NOT NULL,
  `alamat` varchar(40) NOT NULL,
  `poliklinik` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tabinputdata`
--

INSERT INTO `tabinputdata` (`kodepasien`, `nama`, `usia`, `jeniskelamin`, `alamat`, `poliklinik`) VALUES
('PTHT', 'ee', '12', 'Laki-Laki', 'tt', 'Poliklinik THT');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`username`);
--
-- Database: `karyawan`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `username` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Database: `onderdil`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_barang`
--

CREATE TABLE IF NOT EXISTS `tbl_barang` (
  `kd_barang` varchar(10) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `jumlah_barang` int(11) NOT NULL,
  `harga_beli` int(11) NOT NULL,
  `harga_jual` int(11) NOT NULL,
  `tanggal_masuk` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_barang`
--

INSERT INTO `tbl_barang` (`kd_barang`, `nama_barang`, `jumlah_barang`, `harga_beli`, `harga_jual`, `tanggal_masuk`) VALUES
('B0001', 'Pelek', 82, 1000000, 1500000, '2019-06-25'),
('B0002', 'Ban', 73, 100000, 150000, '2019-06-24'),
('B0003', 'Oli', 97, 45000, 50000, '2019-06-23'),
('B0004', 'Busi', 64, 20000, 30000, '2019-06-22'),
('B0005', 'Bohlam', 99, 7000, 15000, '2019-06-21'),
('B0006', 'aki', 4, 100, 400, '2019-07-07');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_beli`
--

CREATE TABLE IF NOT EXISTS `tbl_beli` (
  `nofaktur` varchar(11) NOT NULL,
  `kd_barang` varchar(11) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `hsatuan` int(11) NOT NULL,
  `jumlah_beli` int(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `bayar` int(11) NOT NULL,
  `kembalian` int(11) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_beli`
--

INSERT INTO `tbl_beli` (`nofaktur`, `kd_barang`, `nama_barang`, `hsatuan`, `jumlah_beli`, `harga`, `bayar`, `kembalian`, `tanggal`) VALUES
('F0001', 'B0001', 'Pelek', 1500000, 2, 3000000, 4000000, 1000000, '2019-06-25'),
('F0002', 'B0004', 'Busi', 30000, 2, 60000, 100000, 40000, '2019-06-25'),
('F0003', 'B0003', 'Oli', 50000, 3, 150000, 500000, 50000, '2019-06-25'),
('F0003', 'B0002', 'Ban', 150000, 2, 300000, 500000, 50000, '2019-06-25'),
('F0004', 'B0001', 'Pelek', 1500000, 2, 3000000, 4000000, 1000000, '2019-06-26'),
('F0005', 'B0004', 'Busi', 30000, 2, 60000, 210000, 0, '2019-06-26'),
('F0005', 'B0002', 'Ban', 150000, 1, 150000, 210000, 0, '2019-06-26'),
('F0006', 'B0001', 'Pelek', 1500000, 1, 1500000, 2000000, 500000, '2019-06-27'),
('F0007', 'B0002', 'Ban', 150000, 2, 300000, 400000, 100000, '2019-07-03'),
('F0007', 'B0002', 'Ban', 150000, 2, 300000, 300000, 0, '2019-07-03'),
('F0008', 'B0002', 'Ban', 150000, 2, 300000, 300000, 0, '2019-07-03'),
('F0009', 'B0001', 'Pelek', 1500000, 3, 4500000, 6000000, 1500000, '2019-07-05'),
('F0009', 'B0001', 'Pelek', 1500000, 3, 4500000, 6000000, 1500000, '2019-07-05'),
('F0009', 'B0001', 'Pelek', 1500000, 3, 4500000, 6000000, 1500000, '2019-07-05'),
('F0009', 'B0001', 'Pelek', 1500000, 3, 4500000, 6000000, 1500000, '2019-07-05'),
('F0009', 'B0001', 'Pelek', 1500000, 3, 4500000, 6000000, 1500000, '2019-07-05'),
('F0010', 'B0002', 'Ban', 150000, 2, 300000, 6000000, 1500000, '2019-07-05'),
('F0010', 'B0002', 'Ban', 150000, 2, 300000, 6000000, 1500000, '2019-07-05'),
('F0010', 'B0002', 'Ban', 150000, 2, 300000, 6000000, 1500000, '2019-07-05'),
('F0011', 'B0002', 'Ban', 150000, 2, 300000, 400000, 40000, '2019-07-05'),
('F0011', 'B0004', 'Busi', 30000, 2, 60000, 400000, 40000, '2019-07-05'),
('F0012', 'B0002', 'Ban', 150000, 2, 300000, 2000000, 200000, '2019-07-08'),
('F0012', 'B0001', 'Pelek', 1500000, 1, 1500000, 2000000, 200000, '2019-07-08'),
('F0012', 'B0002', 'Ban', 150000, 2, 300000, 2000000, 200000, '2019-07-08'),
('F0012', 'B0001', 'Pelek', 1500000, 1, 1500000, 2000000, 200000, '2019-07-08'),
('F0013', 'B0002', 'Ban', 150000, 2, 300000, 20000000, 18185000, '2019-07-08'),
('F0013', 'B0001', 'Pelek', 1500000, 1, 1500000, 20000000, 18185000, '2019-07-08'),
('F0013', 'B0005', 'Bohlam', 15000, 1, 15000, 20000000, 18185000, '2019-07-08'),
('F0014', 'B0002', 'Ban', 150000, 2, 300000, 3333333, 1517533, '2019-07-08'),
('F0014', 'B0001', 'Pelek', 1500000, 1, 1500000, 3333333, 1517533, '2019-07-08'),
('F0014', 'B0005', 'Bohlam', 15000, 1, 15000, 3333333, 1517533, '2019-07-08'),
('F0014', 'B0006', 'aki', 400, 2, 800, 3333333, 1517533, '2019-07-08'),
('F0014', 'B0002', 'Ban', 150000, 2, 300000, 3333333, 1517533, '2019-07-08'),
('F0014', 'B0001', 'Pelek', 1500000, 1, 1500000, 3333333, 1517533, '2019-07-08'),
('F0014', 'B0005', 'Bohlam', 15000, 1, 15000, 3333333, 1517533, '2019-07-08'),
('F0014', 'B0006', 'aki', 400, 2, 800, 3333333, 1517533, '2019-07-08'),
('F0014', 'B0002', 'Ban', 150000, 2, 300000, 11111111, 9295311, '2019-07-08'),
('F0014', 'B0001', 'Pelek', 1500000, 1, 1500000, 11111111, 9295311, '2019-07-08'),
('F0014', 'B0005', 'Bohlam', 15000, 1, 15000, 11111111, 9295311, '2019-07-08'),
('F0014', 'B0006', 'aki', 400, 2, 800, 11111111, 9295311, '2019-07-08'),
('F0015', 'B0001', 'Pelek', 1500000, 1, 1500000, 50000000, 48485000, '2019-07-10'),
('F0015', 'B0005', 'Bohlam', 15000, 1, 15000, 50000000, 48485000, '2019-07-10'),
('F0015', 'B0001', 'Pelek', 1500000, 6, 9000000, 50000000, 48485000, '2019-07-10'),
('F0016', 'B0001', 'Pelek', 1500000, 1, 1500000, 100000000, 89485000, '2019-07-10'),
('F0016', 'B0005', 'Bohlam', 15000, 1, 15000, 100000000, 89485000, '2019-07-10'),
('F0016', 'B0001', 'Pelek', 1500000, 6, 9000000, 100000000, 89485000, '2019-07-10'),
('F0017', 'B0002', 'Ban', 150000, 2, 300000, 4000000, 3670000, '2019-07-10'),
('F0017', 'B0004', 'Busi', 30000, 1, 30000, 4000000, 3670000, '2019-07-10'),
('F0018', 'B0001', 'Pelek', 1500000, 3, 4500000, 5000000, 500000, '2019-07-10'),
('F0019', 'B0001', 'Pelek', 1500000, 2, 3000000, 4000000, 1000000, '2019-07-10'),
('F0020', 'B0002', 'Ban', 150000, 2, 300000, 400000, 100000, '2019-07-10');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_login`
--

CREATE TABLE IF NOT EXISTS `tbl_login` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `jenis_kelamin` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `no_telp` int(30) NOT NULL,
  `agama` varchar(30) NOT NULL,
  `alamat` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_login`
--

INSERT INTO `tbl_login` (`username`, `password`, `jenis_kelamin`, `email`, `no_telp`, `agama`, `alamat`) VALUES
('andri', '6bd3108684ccc9dfd40b126877f850b0', 'Perempuan', 'andriansyahh67@gmail.com', 877123456, 'Islam', 'blubuk');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_tmp_beli`
--

CREATE TABLE IF NOT EXISTS `tbl_tmp_beli` (
  `id_tmp` int(11) NOT NULL,
  `kd_barang` varchar(11) NOT NULL,
  `nama_barang` varchar(50) NOT NULL,
  `hsatuan` int(11) NOT NULL,
  `jumlah_beli` int(11) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Trigger `tbl_tmp_beli`
--
DELIMITER $$
CREATE TRIGGER `batal` AFTER DELETE ON `tbl_tmp_beli`
 FOR EACH ROW BEGIN
UPDATE tbl_barang SET jumlah_barang = jumlah_barang + OLD.jumlah_beli
WHERE kd_barang = OLD.kd_barang;
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `beli` AFTER INSERT ON `tbl_tmp_beli`
 FOR EACH ROW BEGIN 
UPDATE tbl_barang SET jumlah_barang = jumlah_barang - new.jumlah_beli 
WHERE kd_barang = new.`kd_barang`; 
END
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_barang`
--
ALTER TABLE `tbl_barang`
  ADD PRIMARY KEY (`kd_barang`);

--
-- Indexes for table `tbl_login`
--
ALTER TABLE `tbl_login`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `tbl_tmp_beli`
--
ALTER TABLE `tbl_tmp_beli`
  ADD PRIMARY KEY (`id_tmp`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_tmp_beli`
--
ALTER TABLE `tbl_tmp_beli`
  MODIFY `id_tmp` int(11) NOT NULL AUTO_INCREMENT;--
-- Database: `p_mahasiswa`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `coba`
--

CREATE TABLE IF NOT EXISTS `coba` (
  `a` varchar(100) NOT NULL,
  `b` int(11) NOT NULL,
  `c` int(11) NOT NULL,
  `d` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `daftar`
--

CREATE TABLE IF NOT EXISTS `daftar` (
  `nama` varchar(100) NOT NULL,
  `a` int(11) NOT NULL,
  `if` int(11) NOT NULL,
  `ig` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `coba`
--
ALTER TABLE `coba`
  ADD PRIMARY KEY (`a`);

--
-- Indexes for table `daftar`
--
ALTER TABLE `daftar`
  ADD PRIMARY KEY (`nama`);

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `coba`
--
ALTER TABLE `coba`
  ADD CONSTRAINT `coba_ibfk_1` FOREIGN KEY (`a`) REFERENCES `daftar` (`nama`);
--
-- Database: `pdo`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `nama` int(11) NOT NULL,
  `username` int(11) NOT NULL,
  `password` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
--
-- Database: `pendaftaran`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `fakultas`
--

CREATE TABLE IF NOT EXISTS `fakultas` (
  `id_fakultas` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `sk_ijin` varchar(100) NOT NULL,
  `tanggal_ijin` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `fakultas`
--

INSERT INTO `fakultas` (`id_fakultas`, `nama`, `sk_ijin`, `tanggal_ijin`) VALUES
(1, 'POLITEKNIK HARBER', 'SK/121-1212/', '2019-12-03');

-- --------------------------------------------------------

--
-- Struktur dari tabel `jalur`
--

CREATE TABLE IF NOT EXISTS `jalur` (
  `id_jalur` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `jalur`
--

INSERT INTO `jalur` (`id_jalur`, `nama`) VALUES
(3, 'SNMPTN'),
(4, 'Jalur Undangan'),
(5, 'SBMPTN'),
(6, 'Ujian Mandiri');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mahasiswa`
--

CREATE TABLE IF NOT EXISTS `mahasiswa` (
  `id_daftar` int(11) NOT NULL,
  `id_jalur` int(11) NOT NULL,
  `pilihan1` int(11) NOT NULL,
  `pilihan2` int(11) NOT NULL,
  `id_statuslulus` int(11) NOT NULL DEFAULT '1',
  `nama` varchar(100) CHARACTER SET latin1 NOT NULL,
  `kelamin` enum('L','P') NOT NULL,
  `tempat_lahir` varchar(100) CHARACTER SET latin1 NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `alamat` varchar(100) CHARACTER SET latin1 NOT NULL,
  `telepon` varchar(100) CHARACTER SET latin1 NOT NULL,
  `handpone` varchar(100) CHARACTER SET latin1 NOT NULL,
  `email` varchar(100) CHARACTER SET latin1 NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `mahasiswa`
--

INSERT INTO `mahasiswa` (`id_daftar`, `id_jalur`, `pilihan1`, `pilihan2`, `id_statuslulus`, `nama`, `kelamin`, `tempat_lahir`, `tanggal_lahir`, `alamat`, `telepon`, `handpone`, `email`) VALUES
(4, 1, 13, 13, 3, 'andi', 'L', 'Slawi', '2019-12-02', 'Slawi', '02345', '0856789100', 'Andi@gmail.com'),
(5, 0, 5, 5, 2, 'Rocky', 'L', 'Tegal', '2019-12-06', 'Pangkah', '02345', '085674312', 'aku@gmail.com'),
(6, 1, 10, 10, 2, 'Yukiko', 'P', 'Bandung', '2019-12-30', 'Cimahi', '023788', '09562341890', 'Yukiko@gmail.com');

-- --------------------------------------------------------

--
-- Struktur dari tabel `prodi`
--

CREATE TABLE IF NOT EXISTS `prodi` (
  `id_prodi` int(11) NOT NULL,
  `id_fakultas` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `sk_ijin` varchar(100) NOT NULL,
  `tanggal_ijin` date NOT NULL,
  `sk_akreditasi` varchar(100) NOT NULL,
  `tanggal_akreditasi` date NOT NULL,
  `status` varchar(2) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `prodi`
--

INSERT INTO `prodi` (`id_prodi`, `id_fakultas`, `nama`, `sk_ijin`, `tanggal_ijin`, `sk_akreditasi`, `tanggal_akreditasi`, `status`) VALUES
(5, 6, 'S1 Sistem Informasi', '293/SK/BAN-PT/Akred/PT/IV/2011', '2011-03-16', '1728/D/T/2005', '2005-01-09', 'B'),
(6, 5, 'S1 Pendidikan Agama Islam', '273/SK/BAN-PT/Akred/PT/IV/2009', '2007-03-23', '1527/D/T/2007', '2005-03-17', 'B'),
(7, 9, 'S1 Sastra Inggris', '298/SK/BAN-PT/Akred/PT/IV/2003', '2016-10-12', '1937/D/T/2003', '2003-01-17', 'B'),
(8, 5, ' S1 Hukum Keluarga Islam', '763/SK/BAN-PT/Akred/PT/IV/2005', '2005-01-20', '2738/D/T/2008', '2008-07-10', 'B'),
(9, 5, 'S1 PGMI', '213/SK/BAN-PT/Akred/PT/IV/2002', '2017-01-20', '2716/D/T/2009', '2009-08-23', 'C'),
(10, 0, ' D3 Bahasa Jepang', '183/SK/BAN-PT/Akred/PT/IV/2015', '2015-10-20', '1628/D/T/2005', '2005-09-12', 'A'),
(11, 9, 'S1 Pendidikan Bahasa Inggris', '343/SK/BAN-PT/Akred/PT/IV/2013', '2013-01-25', '1627/D/T/2008', '2008-01-16', 'B'),
(12, 7, 'S1 Administrasi Bisnis', '103/SK/BAN-PT/Akred/PT/IV/2015', '2015-02-01', '5262/D/T/2003', '2003-12-10', 'B'),
(13, 10, 'S1 Matematika', '113/SK/BAN-PT/Akred/PT/IV/2007', '2007-01-20', '1526/D/T/2007', '2007-06-19', 'B'),
(14, 10, 'S1 Pendidikan Matematika', '213/SK/BAN-PT/Akred/PT/IV/2009', '2009-03-09', '1726/D/T/2008', '2008-08-14', 'B'),
(15, 8, 'D3 Keperawatan', '213/SK/BAN-PT/Akred/PT/IV/2012', '2012-04-28', '5267/D/T/2005', '2005-07-17', 'B'),
(16, 8, 'D3 Kebidanan', '240/SK/ BAN-PT/Akred/S/VI/2014', '2014-11-16', '1376/D/T/2005', '2005-08-07', 'C'),
(17, 8, 'S1 Ilmu Keperawatan', '014/ BAN-PT/Ak-XIV/S1/VII/2011', '2011-01-17', '2976/D/T/2004', '2004-01-16', 'B'),
(18, 8, 'Profesi Ners', '030/SK/ BAN-PT/Ak-XVI/S/XI/2013', '2013-10-12', '1876/D/T/2009', '2009-01-16', 'B'),
(19, 11, 'S2 Manajemen Pendidikan Islam', '213/SK/BAN-PT/Akred/PT/IV/2015', '2015-10-12', '2476/D/T/2012', '2012-01-09', 'B'),
(20, 1, 'Teknik Informatika', 'SK/121-1212/', '2019-12-02', '', '0000-00-00', 'B');

-- --------------------------------------------------------

--
-- Struktur dari tabel `statuslulus`
--

CREATE TABLE IF NOT EXISTS `statuslulus` (
  `id_statuslulus` int(11) NOT NULL,
  `nama` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `statuslulus`
--

INSERT INTO `statuslulus` (`id_statuslulus`, `nama`) VALUES
(1, 'lulus'),
(2, 'lulus'),
(3, 'Tidak Lulus');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `fakultas`
--
ALTER TABLE `fakultas`
  ADD PRIMARY KEY (`id_fakultas`);

--
-- Indexes for table `jalur`
--
ALTER TABLE `jalur`
  ADD PRIMARY KEY (`id_jalur`);

--
-- Indexes for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`id_daftar`);

--
-- Indexes for table `prodi`
--
ALTER TABLE `prodi`
  ADD PRIMARY KEY (`id_prodi`);

--
-- Indexes for table `statuslulus`
--
ALTER TABLE `statuslulus`
  ADD PRIMARY KEY (`id_statuslulus`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `fakultas`
--
ALTER TABLE `fakultas`
  MODIFY `id_fakultas` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `jalur`
--
ALTER TABLE `jalur`
  MODIFY `id_jalur` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  MODIFY `id_daftar` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `prodi`
--
ALTER TABLE `prodi`
  MODIFY `id_prodi` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `statuslulus`
--
ALTER TABLE `statuslulus`
  MODIFY `id_statuslulus` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `fakultas`
--
ALTER TABLE `fakultas`
  ADD CONSTRAINT `fakultas_ibfk_1` FOREIGN KEY (`id_fakultas`) REFERENCES `statuslulus` (`id_statuslulus`);

--
-- Ketidakleluasaan untuk tabel `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD CONSTRAINT `mahasiswa_ibfk_1` FOREIGN KEY (`id_daftar`) REFERENCES `jalur` (`id_jalur`);
--
-- Database: `pendaftaran_pkl`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `kuota`
--

CREATE TABLE IF NOT EXISTS `kuota` (
  `kuota` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pendaftar`
--

CREATE TABLE IF NOT EXISTS `pendaftar` (
  `pendaftar_id` varchar(10) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `sekolah` varchar(100) NOT NULL,
  `jurusan` varchar(100) NOT NULL,
  `foto` varchar(300) NOT NULL DEFAULT 'default.jpg'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pendaftar`
--

INSERT INTO `pendaftar` (`pendaftar_id`, `nama`, `sekolah`, `jurusan`, `foto`) VALUES
('1', 'Akhmad Samroni', 'Politeknik Harapan Bersama Kota tegal', 'Teknik Informatika', 'default.jpg'),
('2', 'Maulana Yusuf', 'Politeknik Harapan Bersama Kota tegal', 'Teknik Informatika', 'default.jpg');

-- --------------------------------------------------------

--
-- Struktur dari tabel `status`
--

CREATE TABLE IF NOT EXISTS `status` (
  `status_id` varchar(10) NOT NULL,
  `nama` varchar(100) NOT NULL,
  `sekolah` varchar(100) NOT NULL,
  `jurusan` varchar(100) NOT NULL,
  `foto` varchar(300) NOT NULL DEFAULT 'default.jpg',
  `status` varchar(100) NOT NULL,
  `tanggal_mulai` date NOT NULL,
  `tanggal_selesai` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `status`
--

INSERT INTO `status` (`status_id`, `nama`, `sekolah`, `jurusan`, `foto`, `status`, `tanggal_mulai`, `tanggal_selesai`) VALUES
('1', 'Akhmad Samroni', 'POliteknik Harapan Bersama Kota Tegal', 'Teknik Informatika', 'default.jpg', 'aktif', '2019-08-01', '2019-08-31');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `user_id` int(10) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `telepon` int(12) NOT NULL,
  `alamat` varchar(100) NOT NULL,
  `sekolah` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `level` varchar(1) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`user_id`, `nama_lengkap`, `username`, `email`, `telepon`, `alamat`, `sekolah`, `password`, `level`) VALUES
(1, 'admin', 'admin', 'admin', 89, '', '', 'd033e22ae348aeb5660fc2140aec35850c4da997', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pendaftar`
--
ALTER TABLE `pendaftar`
  ADD PRIMARY KEY (`pendaftar_id`);

--
-- Indexes for table `status`
--
ALTER TABLE `status`
  ADD PRIMARY KEY (`status_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;--
-- Database: `phl`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbladministrator`
--

CREATE TABLE IF NOT EXISTS `tbladministrator` (
  `id` int(11) NOT NULL,
  `user` varchar(30) NOT NULL,
  `pass` varchar(30) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbladministrator`
--

INSERT INTO `tbladministrator` (`id`, `user`, `pass`) VALUES
(1, 'Administrator', 'admin');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tblusers`
--

CREATE TABLE IF NOT EXISTS `tblusers` (
  `id` int(11) NOT NULL,
  `Username` varchar(20) NOT NULL,
  `Password` varchar(20) NOT NULL,
  `Firstname` text NOT NULL,
  `Lastname` text NOT NULL,
  `Email` varchar(30) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tblusers`
--

INSERT INTO `tblusers` (`id`, `Username`, `Password`, `Firstname`, `Lastname`, `Email`) VALUES
(6, 'TobiramaNidaime', 'hokage123', 'Tobirama', 'Senju', 'nidaimesenjou@gmail.com'),
(7, 'shodaimeHashirama', 'konohashodaihokage01', 'Hashirama', 'Senju', 'shodaimeHokage01@gmail.com'),
(8, 'SaruHokage03', 'hiruzensaru03', 'Hiruzen', 'Sarutobi', 'sarutobiHiruzen@gmail.com'),
(9, 'NamekazeMinato04', 'p@55Test12345', 'Minato', 'Namekaze', 'nameuzumaki@gmail.com');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbladministrator`
--
ALTER TABLE `tbladministrator`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblusers`
--
ALTER TABLE `tblusers`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbladministrator`
--
ALTER TABLE `tbladministrator`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `tblusers`
--
ALTER TABLE `tblusers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=10;--
-- Database: `phpmyadmin`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma_bookmark`
--

CREATE TABLE IF NOT EXISTS `pma_bookmark` (
  `id` int(11) NOT NULL,
  `dbase` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `user` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `query` text COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma_column_info`
--

CREATE TABLE IF NOT EXISTS `pma_column_info` (
  `id` int(5) unsigned NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `column_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `mimetype` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `transformation` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT '',
  `transformation_options` varchar(255) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Column information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma_designer_coords`
--

CREATE TABLE IF NOT EXISTS `pma_designer_coords` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `x` int(11) DEFAULT NULL,
  `y` int(11) DEFAULT NULL,
  `v` tinyint(4) DEFAULT NULL,
  `h` tinyint(4) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for Designer';

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma_history`
--

CREATE TABLE IF NOT EXISTS `pma_history` (
  `id` bigint(20) unsigned NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `sqlquery` text COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='SQL history for phpMyAdmin';

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma_navigationhiding`
--

CREATE TABLE IF NOT EXISTS `pma_navigationhiding` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `item_type` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Hidden items of navigation tree';

--
-- Dumping data untuk tabel `pma_navigationhiding`
--

INSERT INTO `pma_navigationhiding` (`username`, `item_name`, `item_type`, `db_name`, `table_name`) VALUES
('root', 'pendaftar', 'table', 'pendaftaran_pkl', '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma_pdf_pages`
--

CREATE TABLE IF NOT EXISTS `pma_pdf_pages` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `page_nr` int(10) unsigned NOT NULL,
  `page_descr` varchar(50) CHARACTER SET utf8 NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='PDF relation pages for phpMyAdmin';

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma_recent`
--

CREATE TABLE IF NOT EXISTS `pma_recent` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `tables` text COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Recently accessed tables';

--
-- Dumping data untuk tabel `pma_recent`
--

INSERT INTO `pma_recent` (`username`, `tables`) VALUES
('root', '[{"db":"aplikasi_penjualan","table":"barang"},{"db":"aplikasi_penjualan","table":"barang_laku"},{"db":"pendaftaran","table":"fakultas"},{"db":"pendaftaran","table":"jalur"},{"db":"pendaftaran","table":"mahasiswa"},{"db":"p_mahasiswa","table":"coba"},{"db":"p_mahasiswa","table":"daftar"},{"db":"onderdil","table":"tbl_beli"},{"db":"onderdil","table":"tbl_barang"},{"db":"db_websistemmusik","table":"musik"}]');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma_relation`
--

CREATE TABLE IF NOT EXISTS `pma_relation` (
  `master_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `master_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_db` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_table` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `foreign_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma_savedsearches`
--

CREATE TABLE IF NOT EXISTS `pma_savedsearches` (
  `id` int(5) unsigned NOT NULL,
  `username` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `search_data` text COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved searches';

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma_table_coords`
--

CREATE TABLE IF NOT EXISTS `pma_table_coords` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `pdf_page_number` int(11) NOT NULL DEFAULT '0',
  `x` float unsigned NOT NULL DEFAULT '0',
  `y` float unsigned NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for phpMyAdmin PDF output';

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma_table_info`
--

CREATE TABLE IF NOT EXISTS `pma_table_info` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT '',
  `display_field` varchar(64) COLLATE utf8_bin NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma_table_uiprefs`
--

CREATE TABLE IF NOT EXISTS `pma_table_uiprefs` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `prefs` text COLLATE utf8_bin NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tables'' UI preferences';

--
-- Dumping data untuk tabel `pma_table_uiprefs`
--

INSERT INTO `pma_table_uiprefs` (`username`, `db_name`, `table_name`, `prefs`, `last_update`) VALUES
('root', 'si_penjualan_rumah', 'tbl_rumah', '[]', '2019-07-06 08:09:46');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma_tracking`
--

CREATE TABLE IF NOT EXISTS `pma_tracking` (
  `db_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `table_name` varchar(64) COLLATE utf8_bin NOT NULL,
  `version` int(10) unsigned NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `schema_snapshot` text COLLATE utf8_bin NOT NULL,
  `schema_sql` text COLLATE utf8_bin,
  `data_sql` longtext COLLATE utf8_bin,
  `tracking` set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') COLLATE utf8_bin DEFAULT NULL,
  `tracking_active` int(1) unsigned NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin ROW_FORMAT=COMPACT COMMENT='Database changes tracking for phpMyAdmin';

--
-- Dumping data untuk tabel `pma_tracking`
--

INSERT INTO `pma_tracking` (`db_name`, `table_name`, `version`, `date_created`, `date_updated`, `schema_snapshot`, `schema_sql`, `data_sql`, `tracking`, `tracking_active`) VALUES
('pendaftaran_pkl', 'user', 1, '2019-08-21 23:29:35', '2019-08-21 23:29:35', 'a:2:{s:7:"COLUMNS";a:9:{i:0;a:8:{s:5:"Field";s:7:"user_id";s:4:"Type";s:7:"int(10)";s:9:"Collation";N;s:4:"Null";s:2:"NO";s:3:"Key";s:3:"PRI";s:7:"Default";N;s:5:"Extra";s:14:"auto_increment";s:7:"Comment";s:0:"";}i:1;a:8:{s:5:"Field";s:12:"nama_lengkap";s:4:"Type";s:12:"varchar(100)";s:9:"Collation";s:17:"latin1_swedish_ci";s:4:"Null";s:2:"NO";s:3:"Key";s:0:"";s:7:"Default";N;s:5:"Extra";s:0:"";s:7:"Comment";s:0:"";}i:2;a:8:{s:5:"Field";s:8:"username";s:4:"Type";s:12:"varchar(100)";s:9:"Collation";s:17:"latin1_swedish_ci";s:4:"Null";s:2:"NO";s:3:"Key";s:3:"UNI";s:7:"Default";N;s:5:"Extra";s:0:"";s:7:"Comment";s:0:"";}i:3;a:8:{s:5:"Field";s:5:"email";s:4:"Type";s:12:"varchar(100)";s:9:"Collation";s:17:"latin1_swedish_ci";s:4:"Null";s:2:"NO";s:3:"Key";s:0:"";s:7:"Default";N;s:5:"Extra";s:0:"";s:7:"Comment";s:0:"";}i:4;a:8:{s:5:"Field";s:7:"telepon";s:4:"Type";s:7:"int(12)";s:9:"Collation";N;s:4:"Null";s:2:"NO";s:3:"Key";s:0:"";s:7:"Default";N;s:5:"Extra";s:0:"";s:7:"Comment";s:0:"";}i:5;a:8:{s:5:"Field";s:6:"alamat";s:4:"Type";s:12:"varchar(100)";s:9:"Collation";s:17:"latin1_swedish_ci";s:4:"Null";s:2:"NO";s:3:"Key";s:0:"";s:7:"Default";N;s:5:"Extra";s:0:"";s:7:"Comment";s:0:"";}i:6;a:8:{s:5:"Field";s:7:"sekolah";s:4:"Type";s:12:"varchar(100)";s:9:"Collation";s:17:"latin1_swedish_ci";s:4:"Null";s:2:"NO";s:3:"Key";s:0:"";s:7:"Default";N;s:5:"Extra";s:0:"";s:7:"Comment";s:0:"";}i:7;a:8:{s:5:"Field";s:8:"password";s:4:"Type";s:12:"varchar(100)";s:9:"Collation";s:17:"latin1_swedish_ci";s:4:"Null";s:2:"NO";s:3:"Key";s:0:"";s:7:"Default";N;s:5:"Extra";s:0:"";s:7:"Comment";s:0:"";}i:8;a:8:{s:5:"Field";s:5:"level";s:4:"Type";s:10:"varchar(1)";s:9:"Collation";s:17:"latin1_swedish_ci";s:4:"Null";s:2:"NO";s:3:"Key";s:0:"";s:7:"Default";N;s:5:"Extra";s:0:"";s:7:"Comment";s:0:"";}}s:7:"INDEXES";a:2:{i:0;a:13:{s:5:"Table";s:4:"user";s:10:"Non_unique";s:1:"0";s:8:"Key_name";s:7:"PRIMARY";s:12:"Seq_in_index";s:1:"1";s:11:"Column_name";s:7:"user_id";s:9:"Collation";s:1:"A";s:11:"Cardinality";s:1:"0";s:8:"Sub_part";N;s:6:"Packed";N;s:4:"Null";s:0:"";s:10:"Index_type";s:5:"BTREE";s:7:"Comment";s:0:"";s:13:"Index_comment";s:0:"";}i:1;a:13:{s:5:"Table";s:4:"user";s:10:"Non_unique";s:1:"0";s:8:"Key_name";s:8:"username";s:12:"Seq_in_index";s:1:"1";s:11:"Column_name";s:8:"username";s:9:"Collation";s:1:"A";s:11:"Cardinality";s:1:"0";s:8:"Sub_part";N;s:6:"Packed";N;s:4:"Null";s:0:"";s:10:"Index_type";s:5:"BTREE";s:7:"Comment";s:0:"";s:13:"Index_comment";s:0:"";}}}', '# log 2019-08-21 23:29:35 root\nDROP TABLE IF EXISTS `user`;\n# log 2019-08-21 23:29:35 root\n\nCREATE TABLE `user` (\n  `user_id` int(10) NOT NULL,\n  `nama_lengkap` varchar(100) NOT NULL,\n  `username` varchar(100) NOT NULL,\n  `email` varchar(100) NOT NULL,\n  `telepon` int(12) NOT NULL,\n  `alamat` varchar(100) NOT NULL,\n  `sekolah` varchar(100) NOT NULL,\n  `password` varchar(100) NOT NULL,\n  `level` varchar(1) NOT NULL\n) ENGINE=InnoDB DEFAULT CHARSET=latin1;\n', '\n', 'UPDATE,INSERT,DELETE,TRUNCATE,CREATE TABLE,ALTER TABLE,RENAME TABLE,DROP TABLE,CREATE INDEX,DROP INDEX', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma_userconfig`
--

CREATE TABLE IF NOT EXISTS `pma_userconfig` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `timevalue` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `config_data` text COLLATE utf8_bin NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User preferences storage for phpMyAdmin';

--
-- Dumping data untuk tabel `pma_userconfig`
--

INSERT INTO `pma_userconfig` (`username`, `timevalue`, `config_data`) VALUES
('root', '2019-05-14 04:37:08', '{"lang":"id","collation_connection":"utf8mb4_unicode_ci"}');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma_usergroups`
--

CREATE TABLE IF NOT EXISTS `pma_usergroups` (
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL,
  `tab` varchar(64) COLLATE utf8_bin NOT NULL,
  `allowed` enum('Y','N') COLLATE utf8_bin NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User groups with configured menu items';

-- --------------------------------------------------------

--
-- Struktur dari tabel `pma_users`
--

CREATE TABLE IF NOT EXISTS `pma_users` (
  `username` varchar(64) COLLATE utf8_bin NOT NULL,
  `usergroup` varchar(64) COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users and their assignments to user groups';

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pma_bookmark`
--
ALTER TABLE `pma_bookmark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pma_column_info`
--
ALTER TABLE `pma_column_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`);

--
-- Indexes for table `pma_designer_coords`
--
ALTER TABLE `pma_designer_coords`
  ADD PRIMARY KEY (`db_name`,`table_name`);

--
-- Indexes for table `pma_history`
--
ALTER TABLE `pma_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`,`db`,`table`,`timevalue`);

--
-- Indexes for table `pma_navigationhiding`
--
ALTER TABLE `pma_navigationhiding`
  ADD PRIMARY KEY (`username`,`item_name`,`item_type`,`db_name`,`table_name`);

--
-- Indexes for table `pma_pdf_pages`
--
ALTER TABLE `pma_pdf_pages`
  ADD PRIMARY KEY (`page_nr`),
  ADD KEY `db_name` (`db_name`);

--
-- Indexes for table `pma_recent`
--
ALTER TABLE `pma_recent`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma_relation`
--
ALTER TABLE `pma_relation`
  ADD PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  ADD KEY `foreign_field` (`foreign_db`,`foreign_table`);

--
-- Indexes for table `pma_savedsearches`
--
ALTER TABLE `pma_savedsearches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_savedsearches_username_dbname` (`username`,`db_name`,`search_name`);

--
-- Indexes for table `pma_table_coords`
--
ALTER TABLE `pma_table_coords`
  ADD PRIMARY KEY (`db_name`,`table_name`,`pdf_page_number`);

--
-- Indexes for table `pma_table_info`
--
ALTER TABLE `pma_table_info`
  ADD PRIMARY KEY (`db_name`,`table_name`);

--
-- Indexes for table `pma_table_uiprefs`
--
ALTER TABLE `pma_table_uiprefs`
  ADD PRIMARY KEY (`username`,`db_name`,`table_name`);

--
-- Indexes for table `pma_tracking`
--
ALTER TABLE `pma_tracking`
  ADD PRIMARY KEY (`db_name`,`table_name`,`version`);

--
-- Indexes for table `pma_userconfig`
--
ALTER TABLE `pma_userconfig`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma_usergroups`
--
ALTER TABLE `pma_usergroups`
  ADD PRIMARY KEY (`usergroup`,`tab`,`allowed`);

--
-- Indexes for table `pma_users`
--
ALTER TABLE `pma_users`
  ADD PRIMARY KEY (`username`,`usergroup`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pma_bookmark`
--
ALTER TABLE `pma_bookmark`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pma_column_info`
--
ALTER TABLE `pma_column_info`
  MODIFY `id` int(5) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pma_history`
--
ALTER TABLE `pma_history`
  MODIFY `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pma_pdf_pages`
--
ALTER TABLE `pma_pdf_pages`
  MODIFY `page_nr` int(10) unsigned NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `pma_savedsearches`
--
ALTER TABLE `pma_savedsearches`
  MODIFY `id` int(5) unsigned NOT NULL AUTO_INCREMENT;--
-- Database: `projectuasoop2`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `data`
--

CREATE TABLE IF NOT EXISTS `data` (
  `id` int(11) NOT NULL,
  `nama_film` varchar(50) NOT NULL,
  `studio` varchar(2) NOT NULL,
  `harga` varchar(10) NOT NULL,
  `jam` varchar(5) NOT NULL,
  `tanggal` date NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `data`
--

INSERT INTO `data` (`id`, `nama_film`, `studio`, `harga`, `jam`, `tanggal`) VALUES
(2, 'Spiderman HomeComing', '2', 'Rp. 40.000', '14.00', '2019-11-19'),
(4, 'Avenger Endgame', '1', 'Rp. 40.000', '14.00', '2019-11-19');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(15) NOT NULL,
  `hak_akses` enum('Admin','Pelanggan') NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `hak_akses`) VALUES
(3, 'admin', 'admin', 'Admin'),
(4, 'andik', 'andik', 'Pelanggan');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `data`
--
ALTER TABLE `data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `data`
--
ALTER TABLE `data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;--
-- Database: `pw`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `id_admin` int(11) NOT NULL,
  `nama lengkap` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `admin`
--

INSERT INTO `admin` (`id_admin`, `nama lengkap`, `username`, `password`) VALUES
(1, 'rizki', 'admin', 'admin');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pemesan`
--

CREATE TABLE IF NOT EXISTS `pemesan` (
  `id_pemesanan` int(4) NOT NULL,
  `nama` varchar(33) NOT NULL,
  `email` varchar(33) NOT NULL,
  `jumlah` int(4) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pemesan`
--

INSERT INTO `pemesan` (`id_pemesanan`, `nama`, `email`, `jumlah`) VALUES
(1, 'Adjiemas dian n', 'jimzminz0@gmail.com', 2),
(2, 'jempol', 'ozlo9@gmail.com', 1),
(3, 'jempol', 'ozlo9@gmail.com', 1),
(4, 'jempol', 'ozlo9@gmail.com', 1),
(5, 'Adjiemas dian n', 'jimzminz0@gmail.com', 1),
(6, 'jempol', 'ozlo9@gmail.com', 1),
(7, 'Adjiemas dian n', 'jimzminz0@gmail.com', 1),
(8, 'rizki', 'rizki@gmail.com', 2),
(9, 'jempol', 'ozlo9@gmail.com', 2),
(10, 'rizki', 'rizki@gmail.com', 1),
(11, 'rizki', 'rizki@gmail.com', 1),
(12, 'Adjiemas dian n', 'jimzminz0@gmail.com', 1),
(13, 'adjie', 'adji@gmail.com', 1),
(14, 'aji', 'aji@gmail.com', 1),
(15, 'riki', 'riki@email.com', 2),
(16, 'riki', 'riki@email.com', 2),
(17, 'aaa', 'rockynurdiansyah@yahoo.com', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tiket`
--

CREATE TABLE IF NOT EXISTS `tiket` (
  `id_tiket` int(4) NOT NULL,
  `event` varchar(33) NOT NULL,
  `tanggal` varchar(33) NOT NULL,
  `harga` varchar(33) NOT NULL,
  `jenis_tiket` varchar(33) NOT NULL,
  `jumlah` int(4) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tiket`
--

INSERT INTO `tiket` (`id_tiket`, `event`, `tanggal`, `harga`, `jenis_tiket`, `jumlah`) VALUES
(1, 'Konser Amal', '1-1-2019', '35000', 'Festival', 500),
(2, 'Konser Cabit Besari', '3-1-2019', '55000', 'Pre Order (PO)', 200);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user2`
--

CREATE TABLE IF NOT EXISTS `user2` (
  `id` int(8) NOT NULL,
  `user` varchar(33) NOT NULL,
  `password` varchar(55) NOT NULL,
  `status` varchar(15) NOT NULL,
  `email` varchar(33) NOT NULL,
  `gender` varchar(15) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user2`
--

INSERT INTO `user2` (`id`, `user`, `password`, `status`, `email`, `gender`) VALUES
(1, 'admintiket', '21232f297a57a5a743894a0e4a801fc3', 'admin', 'admin@gmail.com', 'laki-laki'),
(2, 'admintiket', '21232f297a57a5a743894a0e4a801fc3', 'admin', 'admin@gmail.com', 'laki-laki'),
(3, 'adjie', '202cb962ac59075b964b07152d234b70', 'user', 'jimzminz0@gmail.com', 'laki-laki'),
(5, 'jempol', 'aaaa', 'user', 'ozlo9@gmail.com', 'laki-laki'),
(6, 'rizki', 'admin', 'user', 'rizki@gmail.com', 'laki-laki'),
(7, 'dasdas', 'sdasd', 'sdasd', 'sdadd@adsa', 'sadad'),
(8, 'asadasd', 'sdada', 'sadad', 'ssdada@aadas', 'asdadsasda');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `pemesan`
--
ALTER TABLE `pemesan`
  ADD PRIMARY KEY (`id_pemesanan`);

--
-- Indexes for table `tiket`
--
ALTER TABLE `tiket`
  ADD PRIMARY KEY (`id_tiket`);

--
-- Indexes for table `user2`
--
ALTER TABLE `user2`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `pemesan`
--
ALTER TABLE `pemesan`
  MODIFY `id_pemesanan` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- AUTO_INCREMENT for table `tiket`
--
ALTER TABLE `tiket`
  MODIFY `id_tiket` int(4) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `user2`
--
ALTER TABLE `user2`
  MODIFY `id` int(8) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;--
-- Database: `si_penjualan_rumah`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  `jenis_kelamin` varchar(20) NOT NULL,
  `email` varchar(100) NOT NULL,
  `no_telp` int(30) NOT NULL,
  `agama` varchar(30) NOT NULL,
  `alamat` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `login`
--

INSERT INTO `login` (`username`, `password`, `jenis_kelamin`, `email`, `no_telp`, `agama`, `alamat`) VALUES
('saya', '5bab541acd761a3093d7c4202b6e1da9', 'Laki-Laki', 'rocky@gmail.com', 852907732, 'islam', 'Tegal');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_pembeli`
--

CREATE TABLE IF NOT EXISTS `tbl_pembeli` (
  `nobeli` varchar(30) NOT NULL,
  `kode_rumah` varchar(30) NOT NULL,
  `tipe_rumah` varchar(30) NOT NULL,
  `harga_satuanrumah` int(15) NOT NULL,
  `jumlah_beli` int(15) NOT NULL,
  `harga` int(15) NOT NULL,
  `bayar` int(15) NOT NULL,
  `kembalian` int(15) NOT NULL,
  `tanggal_beli` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_pembeli`
--

INSERT INTO `tbl_pembeli` (`nobeli`, `kode_rumah`, `tipe_rumah`, `harga_satuanrumah`, `jumlah_beli`, `harga`, `bayar`, `kembalian`, `tanggal_beli`) VALUES
('C0001', 'Mewah', 'C0001', 4000000, 2, 8000000, 9000000, 1000000, '2019-07-11'),
('C0002', 'Menengah', 'C0002', 1500000, 1, 1500000, 6000000, 500000, '2019-07-11'),
('C0002', 'Sederhana', 'C0003', 1000000, 4, 4000000, 6000000, 500000, '2019-07-11'),
('C0003', 'Menengah', 'C0002', 1500000, 1, 1500000, 2000000, 500000, '2019-07-11'),
('C0004', 'Mewah', 'C0001', 4000000, 2, 8000000, 9000000, 1000000, '2019-07-11');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_rumah`
--

CREATE TABLE IF NOT EXISTS `tbl_rumah` (
  `kd_rumah` varchar(10) NOT NULL,
  `tipe_rumah` varchar(50) NOT NULL,
  `jumlah_rumah` int(11) NOT NULL,
  `harga_beli` int(11) NOT NULL,
  `harga_jual` int(11) NOT NULL,
  `tanggal_jual` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tbl_rumah`
--

INSERT INTO `tbl_rumah` (`kd_rumah`, `tipe_rumah`, `jumlah_rumah`, `harga_beli`, `harga_jual`, `tanggal_jual`) VALUES
('C0002', 'Menengah', 4, 2000000, 1500000, '2019-07-11'),
('C0003', 'Sederhana', 4, 1000000, 1000000, '2019-07-11'),
('C0004', 'Mewah Sekali', 3, 5000000, 6000000, '2019-07-11');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tbl_tmpt_beli`
--

CREATE TABLE IF NOT EXISTS `tbl_tmpt_beli` (
  `id_tmp` int(11) NOT NULL,
  `tipe_rumah` varchar(50) NOT NULL,
  `kd_rumah` varchar(50) NOT NULL,
  `hsatuan` int(11) NOT NULL,
  `jumlah_beli` int(11) NOT NULL,
  `harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `tbl_rumah`
--
ALTER TABLE `tbl_rumah`
  ADD PRIMARY KEY (`kd_rumah`);

--
-- Indexes for table `tbl_tmpt_beli`
--
ALTER TABLE `tbl_tmpt_beli`
  ADD PRIMARY KEY (`id_tmp`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_tmpt_beli`
--
ALTER TABLE `tbl_tmpt_beli`
  MODIFY `id_tmp` int(11) NOT NULL AUTO_INCREMENT;--
-- Database: `siswa`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `daftar`
--

CREATE TABLE IF NOT EXISTS `daftar` (
  `id` int(255) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `alamat` text NOT NULL,
  `ttl` text NOT NULL,
  `asal_sekolah` varchar(50) NOT NULL,
  `nisn` int(50) NOT NULL,
  `telepon` int(12) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `daftar`
--

INSERT INTO `daftar` (`id`, `nama`, `alamat`, `ttl`, `asal_sekolah`, `nisn`, `telepon`) VALUES
(16, 'Ahmad Zaelani', 'Parigi', 'Ciamis 30 Juli 1993', 'SMPN 1 Parigi', 3991247, 2147483647),
(17, 'Dadan Sudarman', 'Pangandaran', 'Pangandaran 28 Juli 1997', 'SMPN 1 Pangandaran', 123456, 825885858),
(18, 'Andri Fauzan', 'Cijulang', 'Pangandaran 30 Agustus 2016', 'SMPN 1 Pangandaran', 202202, 2147483647),
(19, 'Dani Sukarman', 'Parigi', 'Pangandaran 28 Juli 1997', 'SMPN 1 Pangandaran', 202202, 2147483647),
(20, 'Widia Lestari', 'Parigi', 'Parigi 28 Mei 1996', 'SMPN 1 Parigi', 654123, 2147483647),
(21, 'Jajang Surajang hulu panjang s', 'Parigi', 'Pangandaran 28 Juli 1997', 'SMPN 1 Pangandaran', 654123, 2147483647),
(22, 'Linda Hildawati', 'Cimerak', 'Cimerak 10 Agustus 1945', 'SMPN 1 Cimerak', 123456, 2147483647);

-- --------------------------------------------------------

--
-- Struktur dari tabel `kunci`
--

CREATE TABLE IF NOT EXISTS `kunci` (
  `id` int(11) NOT NULL,
  `level` int(32) NOT NULL,
  `number_key` varchar(32) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `kunci`
--

INSERT INTO `kunci` (`id`, `level`, `number_key`) VALUES
(8, 1, '5d7023193f48eb1e4e7bad7ca4fecb19');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL,
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `nama` varchar(32) NOT NULL,
  `email` varchar(32) NOT NULL,
  `level` int(11) NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `nama`, `email`, `level`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'Administrator', 'admin@admin.com', 1),
(2, 'admin2', '21232f297a57a5a743894a0e4a801fc3', 'Administrator', 'admingelo@gelo.com', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `daftar`
--
ALTER TABLE `daftar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kunci`
--
ALTER TABLE `kunci`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `daftar`
--
ALTER TABLE `daftar`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `kunci`
--
ALTER TABLE `kunci`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;--
-- Database: `test`
--
--
-- Database: `webauth`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_pwd`
--

CREATE TABLE IF NOT EXISTS `user_pwd` (
  `name` char(30) COLLATE latin1_general_ci NOT NULL DEFAULT '',
  `pass` char(32) COLLATE latin1_general_ci NOT NULL DEFAULT ''
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

--
-- Dumping data untuk tabel `user_pwd`
--

INSERT INTO `user_pwd` (`name`, `pass`) VALUES
('xampp', 'wampp');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user_pwd`
--
ALTER TABLE `user_pwd`
  ADD PRIMARY KEY (`name`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
